package com.psbc.dgtd.business;

import java.util.HashMap;
import java.util.Map;

import com.eos.system.annotation.Bizlet;
import com.pfpj.foundation.database.DatabaseExt;

@Bizlet("")
public class InsertBankCode {  

	@Bizlet("")
	public void BankCode() {

		try {
			Map<String, Object> map1 = new HashMap<String, Object>();
			map1.put("ORGCODE", 350524001);
			map1.put("BANKCODE", "403397400029");
			map1.put("BANKNAME", "中国邮政储蓄银行股份有限公司安溪县支行");
			DatabaseExt.executeNamedSql("default","com.psbc.dgtd.business.bank_code.insertBankCode", map1);
			
			Map<String, Object> map2 = new HashMap<String, Object>();
			map2.put("ORGCODE", 350526004);
			map2.put("BANKCODE", "403397600055");
			map2.put("BANKNAME", "中国邮政储蓄银行股份有限公司德化县支行");
			DatabaseExt.executeNamedSql("default","com.psbc.dgtd.business.bank_code.insertBankCode", map2);
			
			Map<String, Object> map3 = new HashMap<String, Object>();
			map3.put("ORGCODE", 350521001);
			map3.put("BANKCODE", "403397100028");
			map3.put("BANKNAME", "中国邮政储蓄银行股份有限公司惠安县支行");
			DatabaseExt.executeNamedSql("default","com.psbc.dgtd.business.bank_code.insertBankCode", map3);
			
			Map<String, Object> map4 = new HashMap<String, Object>();
			map4.put("ORGCODE", 350582022);
			map4.put("BANKCODE", "403397220222");
			map4.put("BANKNAME", "中国邮政储蓄银行股份有限公司晋江市灵源支行");
			DatabaseExt.executeNamedSql("default","com.psbc.dgtd.business.bank_code.insertBankCode", map4);
			
			Map<String, Object> map5 = new HashMap<String, Object>();
			map5.put("ORGCODE", 350582001);
			map5.put("BANKCODE", "403397200027");
			map5.put("BANKNAME", "中国邮政储蓄银行股份有限公司晋江市支行");
			DatabaseExt.executeNamedSql("default","com.psbc.dgtd.business.bank_code.insertBankCode", map5);
			
			Map<String, Object> map6 = new HashMap<String, Object>();
			map6.put("ORGCODE", 350583026);
			map6.put("BANKCODE", "403397300263");
			map6.put("BANKNAME", "中国邮政储蓄银行股份有限公司南安市滨海支行");
			DatabaseExt.executeNamedSql("default","com.psbc.dgtd.business.bank_code.insertBankCode", map6);
			
			Map<String, Object> map7 = new HashMap<String, Object>();
			map7.put("ORGCODE", 350583001);
			map7.put("BANKCODE", "403397300020");
			map7.put("BANKNAME", "中国邮政储蓄银行股份有限公司南安市支行");
			DatabaseExt.executeNamedSql("default","com.psbc.dgtd.business.bank_code.insertBankCode", map7);
			
			Map<String, Object> map8 = new HashMap<String, Object>();
			map8.put("ORGCODE", 350501006);
			map8.put("BANKCODE", "403397000171");
			map8.put("BANKNAME", "中国邮政储蓄银行股份有限公司泉州市丰泽区支行");
			DatabaseExt.executeNamedSql("default","com.psbc.dgtd.business.bank_code.insertBankCode", map8);
			
			Map<String, Object> map9 = new HashMap<String, Object>();
			map9.put("ORGCODE", 350501007);
			map9.put("BANKCODE", "403397000026");
			map9.put("BANKNAME", "中国邮政储蓄银行股份有限公司泉州市鲤城区支行");
			DatabaseExt.executeNamedSql("default","com.psbc.dgtd.business.bank_code.insertBankCode", map9);
			
			Map<String, Object> map10 = new HashMap<String, Object>();
			map10.put("ORGCODE", 350501024);
			map10.put("BANKCODE", "403397000227");
			map10.put("BANKNAME", "中国邮政储蓄银行股份有限公司泉州市泉港区支行");
			DatabaseExt.executeNamedSql("default","com.psbc.dgtd.business.bank_code.insertBankCode", map10);
			
			Map<String, Object> map11 = new HashMap<String, Object>();
			map11.put("ORGCODE", 350521018);
			map11.put("BANKCODE", "403397100204");
			map11.put("BANKNAME", "中国邮政储蓄银行股份有限公司泉州市台商区支行");
			DatabaseExt.executeNamedSql("default","com.psbc.dgtd.business.bank_code.insertBankCode", map11);
			
			Map<String, Object> map12 = new HashMap<String, Object>();
			map12.put("ORGCODE", 350502098);
			map12.put("BANKCODE", "403397000018");
			map12.put("BANKNAME", "中国邮政储蓄银行股份有限公司泉州市温陵路支行");
			DatabaseExt.executeNamedSql("default","com.psbc.dgtd.business.bank_code.insertBankCode", map12);
			
			Map<String, Object> map13 = new HashMap<String, Object>();
			map13.put("ORGCODE", 350581001);
			map13.put("BANKCODE", "403397800024");
			map13.put("BANKNAME", "中国邮政储蓄银行股份有限公司石狮市支行");
			DatabaseExt.executeNamedSql("default","com.psbc.dgtd.business.bank_code.insertBankCode", map13);
			
			Map<String, Object> map14 = new HashMap<String, Object>();
			map14.put("ORGCODE", 350525001);
			map14.put("BANKCODE", "403397500021");
			map14.put("BANKNAME", "中国邮政储蓄银行股份有限公司永春县支行");
			DatabaseExt.executeNamedSql("default","com.psbc.dgtd.business.bank_code.insertBankCode", map14);
			
			Map<String, Object> map15 = new HashMap<String, Object>();
			map15.put("ORGCODE", 350425001);
			map15.put("BANKCODE", "403395400026");
			map15.put("BANKNAME", "中国邮政储蓄银行股份有限公司大田县支行");
			DatabaseExt.executeNamedSql("default","com.psbc.dgtd.business.bank_code.insertBankCode", map15);
			
			Map<String, Object> map16 = new HashMap<String, Object>();
			map16.put("ORGCODE", 350430001);
			map16.put("BANKCODE", "403395900013");
			map16.put("BANKNAME", "中国邮政储蓄银行股份有限公司建宁县支行");
			DatabaseExt.executeNamedSql("default","com.psbc.dgtd.business.bank_code.insertBankCode", map16);
			
			Map<String, Object> map17 = new HashMap<String, Object>();
			map17.put("ORGCODE", 350428002);
			map17.put("BANKCODE", "403395700011");
			map17.put("BANKNAME", "中国邮政储蓄银行股份有限公司将乐县支行");
			DatabaseExt.executeNamedSql("default","com.psbc.dgtd.business.bank_code.insertBankCode", map17);
			
			Map<String, Object> map18 = new HashMap<String, Object>();
			map18.put("ORGCODE", 350421002);
			map18.put("BANKCODE", "403395100031");
			map18.put("BANKNAME", "中国邮政储蓄银行股份有限公司明溪县支行");
			DatabaseExt.executeNamedSql("default","com.psbc.dgtd.business.bank_code.insertBankCode", map18);
			
			Map<String, Object> map19 = new HashMap<String, Object>();
			map19.put("ORGCODE", 350424001);
			map19.put("BANKCODE", "403395300025");
			map19.put("BANKNAME", "中国邮政储蓄银行股份有限公司宁化县支行");
			DatabaseExt.executeNamedSql("default","com.psbc.dgtd.business.bank_code.insertBankCode", map19);
			
			Map<String, Object> map20 = new HashMap<String, Object>();
			map20.put("ORGCODE", 350423001);
			map20.put("BANKCODE", "403395200024");
			map20.put("BANKNAME", "中国邮政储蓄银行股份有限公司清流县支行");
			DatabaseExt.executeNamedSql("default","com.psbc.dgtd.business.bank_code.insertBankCode", map20);
			
			Map<String, Object> map21 = new HashMap<String, Object>();
			map21.put("ORGCODE", 350401002);
			map21.put("BANKCODE", "403395000039");
			map21.put("BANKNAME", "中国邮政储蓄银行股份有限公司三明市三元区支行");
			DatabaseExt.executeNamedSql("default","com.psbc.dgtd.business.bank_code.insertBankCode", map21);
			
			Map<String, Object> map22 = new HashMap<String, Object>();
			map22.put("ORGCODE", 350401099);
			map22.put("BANKCODE", "403395000014");
			map22.put("BANKNAME", "中国邮政储蓄银行股份有限公司三明市分行");
			DatabaseExt.executeNamedSql("default","com.psbc.dgtd.business.bank_code.insertBankCode", map22);
			
			Map<String, Object> map23 = new HashMap<String, Object>();
			map23.put("ORGCODE", 350402098);
			map23.put("BANKCODE", "403395000006");
			map23.put("BANKNAME", "中国邮政储蓄银行股份有限公司三明市列东街支行");
			DatabaseExt.executeNamedSql("default","com.psbc.dgtd.business.bank_code.insertBankCode", map23);
			
			Map<String, Object> map24 = new HashMap<String, Object>();
			map24.put("ORGCODE", 350401001);
			map24.put("BANKCODE", "403395000022");
			map24.put("BANKNAME", "中国邮政储蓄银行股份有限公司三明市梅列区支行");
			DatabaseExt.executeNamedSql("default","com.psbc.dgtd.business.bank_code.insertBankCode", map24);
			
			Map<String, Object> map25 = new HashMap<String, Object>();
			map25.put("ORGCODE", 350427001);
			map25.put("BANKCODE", "403395600027");
			map25.put("BANKNAME", "中国邮政储蓄银行股份有限公司沙县支行");
			DatabaseExt.executeNamedSql("default","com.psbc.dgtd.business.bank_code.insertBankCode", map25);

			Map<String, Object> map26 = new HashMap<String, Object>();
			map26.put("ORGCODE", 350429012);
			map26.put("BANKCODE", "403395800131");
			map26.put("BANKNAME", "中国邮政储蓄银行股份有限公司泰宁县支行");
			DatabaseExt.executeNamedSql("default","com.psbc.dgtd.business.bank_code.insertBankCode", map26);
			
			Map<String, Object> map27 = new HashMap<String, Object>();
			map27.put("ORGCODE", 350481001);
			map27.put("BANKCODE", "403396000016");
			map27.put("BANKNAME", "中国邮政储蓄银行股份有限公司永安市支行");
			DatabaseExt.executeNamedSql("default","com.psbc.dgtd.business.bank_code.insertBankCode", map27);
			
			Map<String, Object> map28 = new HashMap<String, Object>();
			map28.put("ORGCODE", 350426016);
			map28.put("BANKCODE", "403395500173");
			map28.put("BANKNAME", "中国邮政储蓄银行股份有限公司尤溪县沈城支行");
			DatabaseExt.executeNamedSql("default","com.psbc.dgtd.business.bank_code.insertBankCode", map28);
			
			Map<String, Object> map29 = new HashMap<String, Object>();
			map29.put("ORGCODE", 350426010);
			map29.put("BANKCODE", "403395500116");
			map29.put("BANKNAME", "中国邮政储蓄银行股份有限公司尤溪县支行");
			DatabaseExt.executeNamedSql("default","com.psbc.dgtd.business.bank_code.insertBankCode", map29);
			
			Map<String, Object> map30 = new HashMap<String, Object>();
			map30.put("ORGCODE", 350723009);
			map30.put("BANKCODE", "403401800102");
			map30.put("BANKNAME", "中国邮政储蓄银行股份有限公司光泽县支行");
			DatabaseExt.executeNamedSql("default","com.psbc.dgtd.business.bank_code.insertBankCode", map30);
			
			Map<String, Object> map31 = new HashMap<String, Object>();
			map31.put("ORGCODE", 350783005);
			map31.put("BANKCODE", "403401500062");
			map31.put("BANKNAME", "中国邮政储蓄银行股份有限公司建瓯市支行");
			DatabaseExt.executeNamedSql("default","com.psbc.dgtd.business.bank_code.insertBankCode", map31);
			
			Map<String, Object> map32 = new HashMap<String, Object>();
			map32.put("ORGCODE", 350784001);
			map32.put("BANKCODE", "403401400027");
			map32.put("BANKNAME", "中国邮政储蓄银行股份有限公司南平市建阳区支行");
			DatabaseExt.executeNamedSql("default","com.psbc.dgtd.business.bank_code.insertBankCode", map32);
			
			Map<String, Object> map33 = new HashMap<String, Object>();
			map33.put("ORGCODE", 350702098);
			map33.put("BANKCODE", "403401000016");
			map33.put("BANKNAME", "中国邮政储蓄银行股份有限公司南平市解放东路支行");
			DatabaseExt.executeNamedSql("default","com.psbc.dgtd.business.bank_code.insertBankCode", map33);
			
			Map<String, Object> map34 = new HashMap<String, Object>();
			map34.put("ORGCODE", 350701012);
			map34.put("BANKCODE", "403401000032");
			map34.put("BANKNAME", "中国邮政储蓄银行股份有限公司南平市延平区支行");
			DatabaseExt.executeNamedSql("default","com.psbc.dgtd.business.bank_code.insertBankCode", map34);
			
			Map<String, Object> map35 = new HashMap<String, Object>();
			map35.put("ORGCODE", 350722003);
			map35.put("BANKCODE", "403401600037");
			map35.put("BANKNAME", "中国邮政储蓄银行股份有限公司浦城县支行");
			DatabaseExt.executeNamedSql("default","com.psbc.dgtd.business.bank_code.insertBankCode", map35);
			
			Map<String, Object> map36 = new HashMap<String, Object>();
			map36.put("ORGCODE", 350781001);
			map36.put("BANKCODE", "403401200018");
			map36.put("BANKNAME", "中国邮政储蓄银行股份有限公司邵武市支行");
			DatabaseExt.executeNamedSql("default","com.psbc.dgtd.business.bank_code.insertBankCode", map36);
			
			Map<String, Object> map37 = new HashMap<String, Object>();
			map37.put("ORGCODE", 350721013);
			map37.put("BANKCODE", "403401300149");
			map37.put("BANKNAME", "中国邮政储蓄银行股份有限公司顺昌县支行");
			DatabaseExt.executeNamedSql("default","com.psbc.dgtd.business.bank_code.insertBankCode", map37);
			
			Map<String, Object> map38 = new HashMap<String, Object>();
			map38.put("ORGCODE", 350724001);
			map38.put("BANKCODE", "403401900023");
			map38.put("BANKNAME", "中国邮政储蓄银行股份有限公司松溪县支行");
			DatabaseExt.executeNamedSql("default","com.psbc.dgtd.business.bank_code.insertBankCode", map38);
			
			Map<String, Object> map39 = new HashMap<String, Object>();
			map39.put("ORGCODE", 350782001);
			map39.put("BANKCODE", "403402200027");
			map39.put("BANKNAME", "中国邮政储蓄银行股份有限公司武夷山市支行");
			DatabaseExt.executeNamedSql("default","com.psbc.dgtd.business.bank_code.insertBankCode", map39);
			
			Map<String, Object> map40 = new HashMap<String, Object>();
			map40.put("ORGCODE", 350725002);
			map40.put("BANKCODE", "403402100028");
			map40.put("BANKNAME", "中国邮政储蓄银行股份有限公司政和县支行");
			DatabaseExt.executeNamedSql("default","com.psbc.dgtd.business.bank_code.insertBankCode", map40);
			
			Map<String, Object> map41 = new HashMap<String, Object>();
			map41.put("ORGCODE", 350981001);
			map41.put("BANKCODE", "403403400021");
			map41.put("BANKNAME", "中国邮政储蓄银行股份有限公司福安市支行");
			DatabaseExt.executeNamedSql("default","com.psbc.dgtd.business.bank_code.insertBankCode", map41);
			
			Map<String, Object> map42 = new HashMap<String, Object>();
			map42.put("ORGCODE", 350982001);
			map42.put("BANKCODE", "403403200011");
			map42.put("BANKNAME", "中国邮政储蓄银行股份有限公司福鼎市支行");
			DatabaseExt.executeNamedSql("default","com.psbc.dgtd.business.bank_code.insertBankCode", map42);
			
			Map<String, Object> map43 = new HashMap<String, Object>();
			map43.put("ORGCODE", 350922001);
			map43.put("BANKCODE", "403403500022");
			map43.put("BANKNAME", "中国邮政储蓄银行股份有限公司古田县支行");
			DatabaseExt.executeNamedSql("default","com.psbc.dgtd.business.bank_code.insertBankCode", map43);
			
			Map<String, Object> map44 = new HashMap<String, Object>();
			map44.put("ORGCODE", 350901013);
			map44.put("BANKCODE", "403403000149");
			map44.put("BANKNAME", "中国邮政储蓄银行股份有限公司宁德市蕉城区支行");
			DatabaseExt.executeNamedSql("default","com.psbc.dgtd.business.bank_code.insertBankCode", map44);
			
			Map<String, Object> map45 = new HashMap<String, Object>();
			map45.put("ORGCODE", 350902098);
			map45.put("BANKCODE", "403403099011");
			map45.put("BANKNAME", "中国邮政储蓄银行股份有限公司宁德市东侨开发区支行");
			DatabaseExt.executeNamedSql("default","com.psbc.dgtd.business.bank_code.insertBankCode", map45);
			
			Map<String, Object> map46 = new HashMap<String, Object>();
			map46.put("ORGCODE", 350923001);
			map46.put("BANKCODE", "403403600023");
			map46.put("BANKNAME", "中国邮政储蓄银行股份有限公司屏南县支行");
			DatabaseExt.executeNamedSql("default","com.psbc.dgtd.business.bank_code.insertBankCode", map46);
			
			Map<String, Object> map47 = new HashMap<String, Object>();
			map47.put("ORGCODE", 350924001);
			map47.put("BANKCODE", "403403700024");
			map47.put("BANKNAME", "中国邮政储蓄银行股份有限公司寿宁县支行");
			DatabaseExt.executeNamedSql("default","com.psbc.dgtd.business.bank_code.insertBankCode", map47);
			
			Map<String, Object> map48 = new HashMap<String, Object>();
			map48.put("ORGCODE", 350921001);
			map48.put("BANKCODE", "403403300029");
			map48.put("BANKNAME", "中国邮政储蓄银行霞浦县支行");
			DatabaseExt.executeNamedSql("default","com.psbc.dgtd.business.bank_code.insertBankCode", map48);
			
			Map<String, Object> map49 = new HashMap<String, Object>();
			map49.put("ORGCODE", 350926002);
			map49.put("BANKCODE", "403403900034");
			map49.put("BANKNAME", "中国邮政储蓄银行股份有限公司柘荣县支行");
			DatabaseExt.executeNamedSql("default","com.psbc.dgtd.business.bank_code.insertBankCode", map49);
			
			Map<String, Object> map50 = new HashMap<String, Object>();
			map50.put("ORGCODE", 350925001);
			map50.put("BANKCODE", "403403800025");
			map50.put("BANKNAME", "中国邮政储蓄银行股份有限公司周宁县支行");
			DatabaseExt.executeNamedSql("default","com.psbc.dgtd.business.bank_code.insertBankCode", map50);
			
			Map<String, Object> map51 = new HashMap<String, Object>();
			map51.put("ORGCODE", 350626001);
			map51.put("BANKCODE", "403399600025");
			map51.put("BANKNAME", "中国邮政储蓄银行股份有限公司东山县支行");
			DatabaseExt.executeNamedSql("default","com.psbc.dgtd.business.bank_code.insertBankCode", map51);
			
			Map<String, Object> map52 = new HashMap<String, Object>();
			map52.put("ORGCODE", 350629001);
			map52.put("BANKCODE", "403399900027");
			map52.put("BANKNAME", "中国邮政储蓄银行股份有限公司华安县支行");
			DatabaseExt.executeNamedSql("default","com.psbc.dgtd.business.bank_code.insertBankCode", map52);
			
			Map<String, Object> map53 = new HashMap<String, Object>();
			map53.put("ORGCODE", 350681017);
			map53.put("BANKCODE", "403399100053");
			map53.put("BANKNAME", "中国邮政储蓄银行股份有限公司漳州台商投资区支行");
			DatabaseExt.executeNamedSql("default","com.psbc.dgtd.business.bank_code.insertBankCode", map53);
			
			Map<String, Object> map54 = new HashMap<String, Object>();
			map54.put("ORGCODE", 350681018);
			map54.put("BANKCODE", "403399100199");
			map54.put("BANKNAME", "中国邮政储蓄银行股份有限公司漳州招商局经济技术开发区招商大道支行");
			DatabaseExt.executeNamedSql("default","com.psbc.dgtd.business.bank_code.insertBankCode", map54);
			
			Map<String, Object> map55 = new HashMap<String, Object>();
			map55.put("ORGCODE", 350681001);
			map55.put("BANKCODE", "403399100029");
			map55.put("BANKNAME", "中国邮政储蓄银行股份有限公司龙海市支行");
			DatabaseExt.executeNamedSql("default","com.psbc.dgtd.business.bank_code.insertBankCode", map55);
			
			Map<String, Object> map56 = new HashMap<String, Object>();
			map56.put("ORGCODE", 350627001);
			map56.put("BANKCODE", "403399700026");
			map56.put("BANKNAME", "中国邮政储蓄银行股份有限公司南靖县支行");
			DatabaseExt.executeNamedSql("default","com.psbc.dgtd.business.bank_code.insertBankCode", map56);
			
			Map<String, Object> map57 = new HashMap<String, Object>();
			map57.put("ORGCODE", 350628001);
			map57.put("BANKCODE", "403399800028");
			map57.put("BANKNAME", "中国邮政储蓄银行股份有限公司平和县支行");
			DatabaseExt.executeNamedSql("default","com.psbc.dgtd.business.bank_code.insertBankCode", map57);
			
			Map<String, Object> map58 = new HashMap<String, Object>();
			map58.put("ORGCODE", 350622001);
			map58.put("BANKCODE", "403399200021");
			map58.put("BANKNAME", "中国邮政储蓄银行股份有限公司云霄县支行");
			DatabaseExt.executeNamedSql("default","com.psbc.dgtd.business.bank_code.insertBankCode", map58);
			
			Map<String, Object> map59 = new HashMap<String, Object>();
			map59.put("ORGCODE", 350623002);
			map59.put("BANKCODE", "403399300014");
			map59.put("BANKNAME", "中国邮政储蓄银行股份有限公司漳浦县支行");
			DatabaseExt.executeNamedSql("default","com.psbc.dgtd.business.bank_code.insertBankCode", map59);
			
			Map<String, Object> map60 = new HashMap<String, Object>();
			map60.put("ORGCODE", 350602098);
			map60.put("BANKCODE", "403399099013");
			map60.put("BANKNAME", "中国邮政储蓄银行股份有限公司漳州市九龙支行");
			DatabaseExt.executeNamedSql("default","com.psbc.dgtd.business.bank_code.insertBankCode", map60);
			
			Map<String, Object> map61 = new HashMap<String, Object>();
			map61.put("ORGCODE", 350601002);
			map61.put("BANKCODE", "403399000038");
			map61.put("BANKNAME", "中国邮政储蓄银行股份有限公司漳州市芗城区支行");
			DatabaseExt.executeNamedSql("default","com.psbc.dgtd.business.bank_code.insertBankCode", map61);
			
			Map<String, Object> map62 = new HashMap<String, Object>();
			map62.put("ORGCODE", 350625006);
			map62.put("BANKCODE", "403399500073");
			map62.put("BANKNAME", "中国邮政储蓄银行股份有限公司长泰县兴泰支行");
			DatabaseExt.executeNamedSql("default","com.psbc.dgtd.business.bank_code.insertBankCode", map62);
			
			Map<String, Object> map63 = new HashMap<String, Object>();
			map63.put("ORGCODE", 350625001);
			map63.put("BANKCODE", "403399500016");
			map63.put("BANKNAME", "中国邮政储蓄银行股份有限公司长泰县支行");
			DatabaseExt.executeNamedSql("default","com.psbc.dgtd.business.bank_code.insertBankCode", map63);
			
			Map<String, Object> map64 = new HashMap<String, Object>();
			map64.put("ORGCODE", 350624001);
			map64.put("BANKCODE", "403399400015");
			map64.put("BANKNAME", "中国邮政储蓄银行股份有限公司诏安县支行");
			DatabaseExt.executeNamedSql("default","com.psbc.dgtd.business.bank_code.insertBankCode", map64);
			
			Map<String, Object> map65 = new HashMap<String, Object>();
			map65.put("ORGCODE", 350181017);
			map65.put("BANKCODE", "403391000937");
			map65.put("BANKNAME", "中国邮政储蓄银行股份有限公司福清市支行");
			DatabaseExt.executeNamedSql("default","com.psbc.dgtd.business.bank_code.insertBankCode", map65);
			
			Map<String, Object> map66 = new HashMap<String, Object>();
			map66.put("ORGCODE", 350101051);
			map66.put("BANKCODE", "403391001510");
			map66.put("BANKNAME", "中国邮政储蓄银行股份有限公司福建自贸试验区福州片区支行");
			DatabaseExt.executeNamedSql("default","com.psbc.dgtd.business.bank_code.insertBankCode", map66);
			
			Map<String, Object> map67 = new HashMap<String, Object>();
			map67.put("ORGCODE", 350101006);
			map67.put("BANKCODE", "403391000074");
			map67.put("BANKNAME", "中国邮政储蓄银行股份有限公司福州市鳌峰支行");
			DatabaseExt.executeNamedSql("default","com.psbc.dgtd.business.bank_code.insertBankCode", map67);
			
			Map<String, Object> map68 = new HashMap<String, Object>();
			map68.put("ORGCODE", 350102098);
			map68.put("BANKCODE", "403391000015");
			map68.put("BANKNAME", "中国邮政储蓄银行股份有限公司福州市台江广场支行");
			DatabaseExt.executeNamedSql("default","com.psbc.dgtd.business.bank_code.insertBankCode", map68);
			
			Map<String, Object> map69 = new HashMap<String, Object>();
			map69.put("ORGCODE", 350101009);
			map69.put("BANKCODE", "403391000103");
			map69.put("BANKNAME", "中国邮政储蓄银行股份有限公司福州市台江区支行");
			DatabaseExt.executeNamedSql("default","com.psbc.dgtd.business.bank_code.insertBankCode", map69);
			
			Map<String, Object> map70 = new HashMap<String, Object>();
			map70.put("ORGCODE", 350101011);
			map70.put("BANKCODE", "403391000120");
			map70.put("BANKNAME", "中国邮政储蓄银行股份有限公司福州市晋安区支行");
			DatabaseExt.executeNamedSql("default","com.psbc.dgtd.business.bank_code.insertBankCode", map70);
			
			Map<String, Object> map71 = new HashMap<String, Object>();
			map71.put("ORGCODE", 350101012);
			map71.put("BANKCODE", "403391000138");
			map71.put("BANKNAME", "中国邮政储蓄银行股份有限公司福州市前屿支行");
			DatabaseExt.executeNamedSql("default","com.psbc.dgtd.business.bank_code.insertBankCode", map71);
			
			Map<String, Object> map72 = new HashMap<String, Object>();
			map72.put("ORGCODE", 350101003);
			map72.put("BANKCODE", "403391000040");
			map72.put("BANKNAME", "中国邮政储蓄银行股份有限公司福州市鼓楼区支行");
			DatabaseExt.executeNamedSql("default","com.psbc.dgtd.business.bank_code.insertBankCode", map72);
			
			Map<String, Object> map73 = new HashMap<String, Object>();
			map73.put("ORGCODE", 350101029);
			map73.put("BANKCODE", "403391000306");
			map73.put("BANKNAME", "中国邮政储蓄银行股份有限公司福州市华林支行");
			DatabaseExt.executeNamedSql("default","com.psbc.dgtd.business.bank_code.insertBankCode", map73);
			
			Map<String, Object> map74 = new HashMap<String, Object>();
			map74.put("ORGCODE", 350101008);
			map74.put("BANKCODE", "403391000099");
			map74.put("BANKNAME", "中国邮政储蓄银行股份有限公司福州市仓山区支行");
			DatabaseExt.executeNamedSql("default","com.psbc.dgtd.business.bank_code.insertBankCode", map74);
			
			Map<String, Object> map75 = new HashMap<String, Object>();
			map75.put("ORGCODE", 350101050);
			map75.put("BANKCODE", "403391001114");
			map75.put("BANKNAME", "中国邮政储蓄银行股份有限公司福州市建新支行");
			DatabaseExt.executeNamedSql("default","com.psbc.dgtd.business.bank_code.insertBankCode", map75);
			
			Map<String, Object> map76 = new HashMap<String, Object>();
			map76.put("ORGCODE", 350101007);
			map76.put("BANKCODE", "403391000082");
			map76.put("BANKNAME", "中国邮政储蓄银行股份有限公司福州市埔顶支行");
			DatabaseExt.executeNamedSql("default","com.psbc.dgtd.business.bank_code.insertBankCode", map76);
			
			Map<String, Object> map77 = new HashMap<String, Object>();
			map77.put("ORGCODE", 350101036);
			map77.put("BANKCODE", "403391000371");
			map77.put("BANKNAME", "中国邮政储蓄银行股份有限公司福州市浦上支行");
			DatabaseExt.executeNamedSql("default","com.psbc.dgtd.business.bank_code.insertBankCode", map77);
			
			Map<String, Object> map78 = new HashMap<String, Object>();
			map78.put("ORGCODE", 350122001);
			map78.put("BANKCODE", "403391000550");
			map78.put("BANKNAME", "中国邮政储蓄银行股份有限公司连江县支行");
			DatabaseExt.executeNamedSql("default","com.psbc.dgtd.business.bank_code.insertBankCode", map78);
			
			Map<String, Object> map79 = new HashMap<String, Object>();
			map79.put("ORGCODE", 350123002);
			map79.put("BANKCODE", "403391000630");
			map79.put("BANKNAME", "中国邮政储蓄银行股份有限公司罗源县支行");
			DatabaseExt.executeNamedSql("default","com.psbc.dgtd.business.bank_code.insertBankCode", map79);
			
			Map<String, Object> map80 = new HashMap<String, Object>();
			map80.put("ORGCODE", 350121016);
			map80.put("BANKCODE", "403391001421");
			map80.put("BANKNAME", "中国邮政储蓄银行股份有限公司闽侯县马腾支行");
			DatabaseExt.executeNamedSql("default","com.psbc.dgtd.business.bank_code.insertBankCode", map80);
			
			Map<String, Object> map81 = new HashMap<String, Object>();
			map81.put("ORGCODE", 350121001);
			map81.put("BANKCODE", "403391000435");
			map81.put("BANKNAME", "中国邮政储蓄银行股份有限公司闽侯县支行");
			DatabaseExt.executeNamedSql("default","com.psbc.dgtd.business.bank_code.insertBankCode", map81);
			
			Map<String, Object> map82 = new HashMap<String, Object>();
			map82.put("ORGCODE", 350124002);
			map82.put("BANKCODE", "403391000672");
			map82.put("BANKNAME", "中国邮政储蓄银行股份有限公司闽清县支行");
			DatabaseExt.executeNamedSql("default","com.psbc.dgtd.business.bank_code.insertBankCode", map82);
			
			Map<String, Object> map83 = new HashMap<String, Object>();
			map83.put("ORGCODE", 350125001);
			map83.put("BANKCODE", "403391000769");
			map83.put("BANKNAME", "中国邮政储蓄银行股份有限公司永泰县支行");
			DatabaseExt.executeNamedSql("default","com.psbc.dgtd.business.bank_code.insertBankCode", map83);
			
			Map<String, Object> map84 = new HashMap<String, Object>();
			map84.put("ORGCODE", 350182001);
			map84.put("BANKCODE", "403391000824");
			map84.put("BANKNAME", "中国邮政储蓄银行股份有限公司长乐市支行");
			DatabaseExt.executeNamedSql("default","com.psbc.dgtd.business.bank_code.insertBankCode", map84);
			
			Map<String, Object> map85 = new HashMap<String, Object>();
			map85.put("ORGCODE", 350825001);
			map85.put("BANKCODE", "403405700027");
			map85.put("BANKNAME", "中国邮政储蓄银行股份有限公司连城县支行");
			DatabaseExt.executeNamedSql("default","com.psbc.dgtd.business.bank_code.insertBankCode", map85);
			
			Map<String, Object> map86 = new HashMap<String, Object>();
			map86.put("ORGCODE", 350801028);
			map86.put("BANKCODE", "403405000013");
			map86.put("BANKNAME", "中国邮政储蓄银行股份有限公司龙岩市分行");
			DatabaseExt.executeNamedSql("default","com.psbc.dgtd.business.bank_code.insertBankCode", map86);
			
			Map<String, Object> map87 = new HashMap<String, Object>();
			map87.put("ORGCODE", 350801022);
			map87.put("BANKCODE", "403405000216");
			map87.put("BANKNAME", "中国邮政储蓄银行股份有限公司龙岩市龙腾路支行");
			DatabaseExt.executeNamedSql("default","com.psbc.dgtd.business.bank_code.insertBankCode", map87);
			
			Map<String, Object> map88 = new HashMap<String, Object>();
			map88.put("ORGCODE", 350801001);
			map88.put("BANKCODE", "403405000021");
			map88.put("BANKNAME", "中国邮政储蓄银行股份有限公司龙岩市新罗区支行");
			DatabaseExt.executeNamedSql("default","com.psbc.dgtd.business.bank_code.insertBankCode", map88);
			
			Map<String, Object> map89 = new HashMap<String, Object>();
			map89.put("ORGCODE", 350823001);
			map89.put("BANKCODE", "403405400105");
			map89.put("BANKNAME", "中国邮政储蓄银行股份有限公司上杭县支行");
			DatabaseExt.executeNamedSql("default","com.psbc.dgtd.business.bank_code.insertBankCode", map89);
			
			Map<String, Object> map90 = new HashMap<String, Object>();
			map90.put("ORGCODE", 350824001);
			map90.put("BANKCODE", "403405500018");
			map90.put("BANKNAME", "中国邮政储蓄银行股份有限公司武平县支行");
			DatabaseExt.executeNamedSql("default","com.psbc.dgtd.business.bank_code.insertBankCode", map90);
			
			Map<String, Object> map91 = new HashMap<String, Object>();
			map91.put("ORGCODE", 350822001);
			map91.put("BANKCODE", "403405300024");
			map91.put("BANKNAME", "中国邮政储蓄银行股份有限公司龙岩市永定区支行");
			DatabaseExt.executeNamedSql("default","com.psbc.dgtd.business.bank_code.insertBankCode", map91);
			
			Map<String, Object> map92 = new HashMap<String, Object>();
			map92.put("ORGCODE", 350822020);
			map92.put("BANKCODE", "403405300153");
			map92.put("BANKNAME", "中国邮政储蓄银行股份有限公司龙岩市永丰支行");
			DatabaseExt.executeNamedSql("default","com.psbc.dgtd.business.bank_code.insertBankCode", map92);
			
			Map<String, Object> map93 = new HashMap<String, Object>();
			map93.put("ORGCODE", 350881001);
			map93.put("BANKCODE", "403405600028");
			map93.put("BANKNAME", "中国邮政储蓄银行股份有限公司漳平市支行");
			DatabaseExt.executeNamedSql("default","com.psbc.dgtd.business.bank_code.insertBankCode", map93);
			
			Map<String, Object> map94 = new HashMap<String, Object>();
			map94.put("ORGCODE", 350821009);
			map94.put("BANKCODE", "403405200015");
			map94.put("BANKNAME", "中国邮政储蓄银行股份有限公司长汀县支行");
			DatabaseExt.executeNamedSql("default","com.psbc.dgtd.business.bank_code.insertBankCode", map94);
			
			Map<String, Object> map95 = new HashMap<String, Object>();
			map95.put("ORGCODE", 350301019);
			map95.put("BANKCODE", "403394000203");
			map95.put("BANKNAME", "中国邮政储蓄银行股份有限公司莆田市秀屿区支行");
			DatabaseExt.executeNamedSql("default","com.psbc.dgtd.business.bank_code.insertBankCode", map95);
			
			Map<String, Object> map96 = new HashMap<String, Object>();
			map96.put("ORGCODE", 350301002);
			map96.put("BANKCODE", "403394000037");
			map96.put("BANKNAME", "中国邮政储蓄银行股份有限公司莆田市荔城区支行");
			DatabaseExt.executeNamedSql("default","com.psbc.dgtd.business.bank_code.insertBankCode", map96);
			
			Map<String, Object> map97 = new HashMap<String, Object>();
			map97.put("ORGCODE", 350301001);
			map97.put("BANKCODE", "403394000029");
			map97.put("BANKNAME", "中国邮政储蓄银行股份有限公司莆田市涵江区支行");
			DatabaseExt.executeNamedSql("default","com.psbc.dgtd.business.bank_code.insertBankCode", map97);
			
			Map<String, Object> map98 = new HashMap<String, Object>();
			map98.put("ORGCODE", 350301004);
			map98.put("BANKCODE", "403394000053");
			map98.put("BANKNAME", "中国邮政储蓄银行股份有限公司莆田市城厢区支行");
			DatabaseExt.executeNamedSql("default","com.psbc.dgtd.business.bank_code.insertBankCode", map98);
			
			Map<String, Object> map99 = new HashMap<String, Object>();
			map99.put("ORGCODE", 350301043);
			map99.put("BANKCODE", "403394000375");
			map99.put("BANKNAME", "中国邮政储蓄银行股份有限公司莆田市龙桥支行");
			DatabaseExt.executeNamedSql("default","com.psbc.dgtd.business.bank_code.insertBankCode", map99);
			
			Map<String, Object> map100 = new HashMap<String, Object>();
			map100.put("ORGCODE", 350302098);
			map100.put("BANKCODE", "403394000359");
			map100.put("BANKNAME", "中国邮政储蓄银行股份有限公司莆田市文献路支行");
			DatabaseExt.executeNamedSql("default","com.psbc.dgtd.business.bank_code.insertBankCode", map100);
			
			Map<String, Object> map101 = new HashMap<String, Object>();
			map101.put("ORGCODE", 350322010);
			map101.put("BANKCODE", "403394200127");
			map101.put("BANKNAME", "中国邮政储蓄银行股份有限公司仙游县支行");
			DatabaseExt.executeNamedSql("default","com.psbc.dgtd.business.bank_code.insertBankCode", map101);

		} catch (Exception e) {
			e.printStackTrace();

		}

	}
	
	@Bizlet("")
	public void updateBankCode() {

		try {
			Map<String, Object> map1 = new HashMap<String, Object>();
			map1.put("BANKCODE", "403405700027");
			map1.put("BANKNAME", "邮储银行连城县支行");
			DatabaseExt.executeNamedSql("default","com.psbc.dgtd.business.bank_code.updateBankCode", map1);
			
			Map<String, Object> map2 = new HashMap<String, Object>();
			map2.put("BANKCODE", "403405000013");
			map2.put("BANKNAME", "邮储银行龙岩市分行");
			DatabaseExt.executeNamedSql("default","com.psbc.dgtd.business.bank_code.updateBankCode", map2);
			
			Map<String, Object> map3 = new HashMap<String, Object>();
			map3.put("BANKCODE", "403405000216");
			map3.put("BANKNAME", "邮储银行龙岩市龙腾路支行");
			DatabaseExt.executeNamedSql("default","com.psbc.dgtd.business.bank_code.updateBankCode", map3);
			
			Map<String, Object> map4 = new HashMap<String, Object>();
			map4.put("BANKCODE", "403405000021");
			map4.put("BANKNAME", "邮储银行龙岩市新罗区支行");
			DatabaseExt.executeNamedSql("default","com.psbc.dgtd.business.bank_code.updateBankCode", map4);
			
			Map<String, Object> map5 = new HashMap<String, Object>();
			map5.put("BANKCODE", "403405400105");
			map5.put("BANKNAME", "邮储银行上杭县支行");
			DatabaseExt.executeNamedSql("default","com.psbc.dgtd.business.bank_code.updateBankCode", map5);
			
			Map<String, Object> map6 = new HashMap<String, Object>();
			map6.put("BANKCODE", "403405500018");
			map6.put("BANKNAME", "邮储银行武平县支行");
			DatabaseExt.executeNamedSql("default","com.psbc.dgtd.business.bank_code.updateBankCode", map6);
			
			Map<String, Object> map7 = new HashMap<String, Object>();
			map7.put("BANKCODE", "403405300024");
			map7.put("BANKNAME", "邮储银行龙岩市永定区支行");
			DatabaseExt.executeNamedSql("default","com.psbc.dgtd.business.bank_code.updateBankCode", map7);
			
			Map<String, Object> map8 = new HashMap<String, Object>();
			map8.put("BANKCODE", "403405300153");
			map8.put("BANKNAME", "邮储银行龙岩市永丰支行");
			DatabaseExt.executeNamedSql("default","com.psbc.dgtd.business.bank_code.updateBankCode", map8);
			
			Map<String, Object> map9 = new HashMap<String, Object>();
			map9.put("BANKCODE", "403405600028");
			map9.put("BANKNAME", "邮储银行漳平市支行");
			DatabaseExt.executeNamedSql("default","com.psbc.dgtd.business.bank_code.updateBankCode", map9);
			
			Map<String, Object> map10 = new HashMap<String, Object>();
			map10.put("BANKCODE", "403405200015");
			map10.put("BANKNAME", "邮储银行长汀县支行");
			DatabaseExt.executeNamedSql("default","com.psbc.dgtd.business.bank_code.updateBankCode", map10);
			
			Map<String, Object> map11 = new HashMap<String, Object>();
			map11.put("BANKCODE", "403401800102");
			map11.put("BANKNAME", "邮政储蓄银行光泽县支行");
			DatabaseExt.executeNamedSql("default","com.psbc.dgtd.business.bank_code.updateBankCode", map11);
			
			Map<String, Object> map12 = new HashMap<String, Object>();
			map12.put("BANKCODE", "403401500062");
			map12.put("BANKNAME", "邮政储蓄银行建瓯市支行");
			DatabaseExt.executeNamedSql("default","com.psbc.dgtd.business.bank_code.updateBankCode", map12);
			
			Map<String, Object> map13 = new HashMap<String, Object>();
			map13.put("BANKCODE", "403401400027");
			map13.put("BANKNAME", "邮政储蓄银行南平市建阳区支行");
			DatabaseExt.executeNamedSql("default","com.psbc.dgtd.business.bank_code.updateBankCode", map13);
			
			Map<String, Object> map14 = new HashMap<String, Object>();
			map14.put("BANKCODE", "403401000016");
			map14.put("BANKNAME", "邮政储蓄银行南平市解放东路支行");
			DatabaseExt.executeNamedSql("default","com.psbc.dgtd.business.bank_code.updateBankCode", map14);
			
			Map<String, Object> map15 = new HashMap<String, Object>();
			map15.put("BANKCODE", "403401000032");
			map15.put("BANKNAME", "邮政储蓄银行南平市延平区支行");
			DatabaseExt.executeNamedSql("default","com.psbc.dgtd.business.bank_code.updateBankCode", map15);
			
			Map<String, Object> map16 = new HashMap<String, Object>();
			map16.put("BANKCODE", "403401600037");
			map16.put("BANKNAME", "邮政储蓄银行浦城县支行");
			DatabaseExt.executeNamedSql("default","com.psbc.dgtd.business.bank_code.updateBankCode", map16);
			
			Map<String, Object> map17 = new HashMap<String, Object>();
			map17.put("BANKCODE", "403401200018");
			map17.put("BANKNAME", "邮政储蓄银行邵武市支行");
			DatabaseExt.executeNamedSql("default","com.psbc.dgtd.business.bank_code.updateBankCode", map17);
			
			Map<String, Object> map18 = new HashMap<String, Object>();
			map18.put("BANKCODE", "403401300149");
			map18.put("BANKNAME", "邮政储蓄银行顺昌县支行");
			DatabaseExt.executeNamedSql("default","com.psbc.dgtd.business.bank_code.updateBankCode", map18);
			
			Map<String, Object> map19 = new HashMap<String, Object>();
			map19.put("BANKCODE", "403401900023");
			map19.put("BANKNAME", "邮政储蓄银行松溪县支行");
			DatabaseExt.executeNamedSql("default","com.psbc.dgtd.business.bank_code.updateBankCode", map19);
			
			Map<String, Object> map20 = new HashMap<String, Object>();
			map20.put("BANKCODE", "403402200027");
			map20.put("BANKNAME", "邮政储蓄银行武夷山市支行");
			DatabaseExt.executeNamedSql("default","com.psbc.dgtd.business.bank_code.updateBankCode", map20);
			
			Map<String, Object> map21 = new HashMap<String, Object>();
			map21.put("BANKCODE", "403402100028");
			map21.put("BANKNAME", "邮政储蓄银行政和县支行");
			DatabaseExt.executeNamedSql("default","com.psbc.dgtd.business.bank_code.updateBankCode", map21);
			
			Map<String, Object> map22 = new HashMap<String, Object>();
			map22.put("BANKCODE", "403403400021");
			map22.put("BANKNAME", "中国邮政储蓄银行股份有限公司福安市支行");
			DatabaseExt.executeNamedSql("default","com.psbc.dgtd.business.bank_code.updateBankCode", map22);
			
			Map<String, Object> map23 = new HashMap<String, Object>();
			map23.put("BANKCODE", "403403200011");
			map23.put("BANKNAME", "中国邮政储蓄银行股份有限公司福鼎市支行");
			DatabaseExt.executeNamedSql("default","com.psbc.dgtd.business.bank_code.updateBankCode", map23);
			
			Map<String, Object> map24 = new HashMap<String, Object>();
			map24.put("BANKCODE", "403403500022");
			map24.put("BANKNAME", "中国邮政储蓄银行股份有限公司古田县支行");
			DatabaseExt.executeNamedSql("default","com.psbc.dgtd.business.bank_code.updateBankCode", map24);
			
			Map<String, Object> map25 = new HashMap<String, Object>();
			map25.put("BANKCODE", "403403000149");
			map25.put("BANKNAME", "邮储银行宁德市蕉城区支行");
			DatabaseExt.executeNamedSql("default","com.psbc.dgtd.business.bank_code.updateBankCode", map25);
			
			Map<String, Object> map26 = new HashMap<String, Object>();
			map26.put("BANKCODE", "403403099011");
			map26.put("BANKNAME", "中国邮政储蓄银行股份有限公司宁德市东侨开发区支行");
			DatabaseExt.executeNamedSql("default","com.psbc.dgtd.business.bank_code.updateBankCode", map26);
			
			Map<String, Object> map27 = new HashMap<String, Object>();
			map27.put("BANKCODE", "403403600023");
			map27.put("BANKNAME", "中国邮政储蓄银行股份有限公司屏南县支行");
			DatabaseExt.executeNamedSql("default","com.psbc.dgtd.business.bank_code.updateBankCode", map27);
			
			Map<String, Object> map28 = new HashMap<String, Object>();
			map28.put("BANKCODE", "403403700024");
			map28.put("BANKNAME", "中国邮政储蓄银行股份有限公司寿宁县支行");
			DatabaseExt.executeNamedSql("default","com.psbc.dgtd.business.bank_code.updateBankCode", map28);
			
			Map<String, Object> map29 = new HashMap<String, Object>();
			map29.put("BANKCODE", "403403300029");
			map29.put("BANKNAME", "中国邮政储蓄银行霞浦县支行");
			DatabaseExt.executeNamedSql("default","com.psbc.dgtd.business.bank_code.updateBankCode", map29);
			
			Map<String, Object> map30 = new HashMap<String, Object>();
			map30.put("BANKCODE", "403403900034");
			map30.put("BANKNAME", "中国邮政储蓄银行股份有限公司柘荣县支行");
			DatabaseExt.executeNamedSql("default","com.psbc.dgtd.business.bank_code.updateBankCode", map30);
			
			Map<String, Object> map31 = new HashMap<String, Object>();
			map31.put("BANKCODE", "403403800025");
			map31.put("BANKNAME", "中国邮政储蓄银行股份有限公司周宁县支行");
			DatabaseExt.executeNamedSql("default","com.psbc.dgtd.business.bank_code.updateBankCode", map31);
		

		} catch (Exception e) {
			e.printStackTrace();

		}

	}

}
