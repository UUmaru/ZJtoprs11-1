package com.psbc.dgtd.business;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.Reader;
import java.sql.Clob;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.alibaba.fastjson.JSON;
import com.eos.system.annotation.Bizlet;

@Bizlet
public class LocalTemplateProcessor {

	@Bizlet
	public Map<String, Object> dealQueryData(HashMap<String, Object>[] maps) {
		Clob clob = null;
		if(maps==null || maps.length==0){
			return null;
		}
		if(maps[0].get("PSEUDOCODE") instanceof Clob){
			clob = (Clob)maps[0].get("PSEUDOCODE");
		}else{
			return null;
		}
		
		Reader is  = null;
		BufferedReader br  = null;
		String line = null;
		int index = 1;
		Map<String,Object> map = new HashMap<String,Object>();
		Map<String,String[]> subMap = new HashMap<String,String[]>();
		map.put("EXC_LOCAL_ID",maps[0].get("EXC_LOCAL_ID"));
		map.put("GMT_CREATED",maps[0].get("GMT_CREATED"));
		try {
			is = clob.getCharacterStream();
			br = new BufferedReader(is);
			line = br.readLine();
			String[] strData = new String[12];
			while(line!=null){
				if(line.startsWith("LODOP.ADD_PRINT_TEXT")){
					//System.out.println(line);
					Pattern pattern = Pattern.compile("(?<=\\().*?(?=\\))");
					Matcher matcher = pattern.matcher(line);
					String[] str = null;
					while(matcher.find()){
						str = matcher.group().split(",");
					}
					strData = new String[12];
					//String[] strData = new String[]{str[0],str[1],str[2],str[3]};
					strData[0]=str[0];
					strData[1]=str[1];
					strData[2]=str[2];
					strData[3]=str[3];
					//subMap.put("index"+index, strData);
					index++;
				}

				if(line.startsWith("LODOP.SET_PRINT_STYLEA")&&!line.contains("FontColor")){
					String[] str = null;
					//System.out.println(line);
					line = line.substring(line.indexOf("(")+1,line.indexOf(")")).toString();
					str=line.split(",");
					str[2]=str[2].replace("\"", "");
					if(line.contains("FontName")){
						strData[4]=str[2];
					}else if(strData[4]==""||strData[4]==null){
						strData[4]="黑体";
					}
					if(line.contains("FontSize")){
						strData[5]=str[2];
					}else if(strData[5]==""||strData[5]==null){
						strData[5]="9";
					}
					if(line.contains("Bold")){
						strData[6]=str[2];
					}else if(strData[6]==""||strData[6]==null){
						strData[6]="0";
					}
					if(line.contains("Italic")){
						strData[7]=str[2];
					}else if(strData[7]==""||strData[7]==null){
						strData[7]="0";
					}
					if(line.contains("Underline")){
						strData[8]=str[2];
					}else if(strData[8]==""||strData[8]==null){
						strData[8]="0";
					}
					if(line.contains("LineSpacing")){
						strData[9]=str[2];
					}else if(strData[9]==""||strData[9]==null){
						strData[9]="0";
					}
					if(line.contains("LetterSpacing")){
						strData[10]=str[2];
					}else if(strData[10]==""||strData[10]==null){
						strData[10]="0";
					}
					if(line.contains("Alignment")){
						strData[11]=str[2];
					}else if(strData[11]==""||strData[11]==null){
						strData[11]="1";
					}
				}else{
					if(strData[4]==""||strData[4]==null){
						strData[4]="黑体";
					}
					if(strData[5]==""||strData[5]==null){
						strData[5]="9";
					}
					if(strData[6]==""||strData[6]==null){
						strData[6]="0";
					}
					if(strData[7]==""||strData[7]==null){
						strData[7]="0";
					}
					if(strData[8]==""||strData[8]==null){
						strData[8]="0";
					}
					if(strData[9]==""||strData[9]==null){
						strData[9]="0";
					}
					if(strData[10]==""||strData[10]==null){
						strData[10]="0";
					}
					if(strData[11]==""||strData[11]==null){
						strData[11]="1";
					}
				}
				/*if(!Arrays.asList(strData).contains(null)){

					subMap.put("index"+(index-1), strData);
					System.out.println("submap="+JSON.toJSONString(subMap));
				}*/
				subMap.put("index"+(index-1), strData);
				//System.out.println("strData="+JSON.toJSONString(strData));
				//System.out.println("submap="+JSON.toJSONString(subMap));
				//System.out.println("submap="+JSON.toJSONString(subMap));
				//index++;
				line = br.readLine();
			}
		} catch (SQLException | IOException e) {
			e.printStackTrace();
		}finally{
			if(br!=null){
				try {
					br.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
			if(is!=null){
				try {
					is.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
		map.put("PSEUDOCODE", subMap);
		return map;
	}
	
	/**
	 * 数据库clob类型转成String
	 * @param clob
	 * @return
	 * @throws SQLException
	 * @throws IOException
	 */
	@Bizlet
	public Map<String, Object> ClobToString(HashMap<String, Object>[] maps)
			throws SQLException, IOException {
		String reString = null;
		Clob clob = null;
		if (maps == null || maps.length == 0) {
			return null;
		}
		if (maps[0].get("PSEUDOCODE") instanceof Clob) {
			clob = (Clob) maps[0].get("PSEUDOCODE");
		} else {
			return null;
		}
		if (clob != null) {
			Reader is = clob.getCharacterStream();
			BufferedReader br = new BufferedReader(is);
			String s = br.readLine();
			StringBuffer sb = new StringBuffer();
			while (s != null) {
				sb.append("\n"+s);
				s = br.readLine();
			}
			reString = sb.toString();
			if (br != null) {
				br.close();
			}
			if (is != null) {
				is.close();
			}
		}
		//System.out.println(reString);
		/*for(int i=0;i<reString.length();i++){
			if(reString.contains("LODOP")){
				
			}
		}*/
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("PSEUDOCODE", reString);

		return map;
	}
}
