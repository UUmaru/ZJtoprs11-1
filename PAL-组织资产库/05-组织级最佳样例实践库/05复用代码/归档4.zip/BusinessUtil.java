package com.psbc.dgtd.business;


import java.io.File;
import java.lang.reflect.InvocationTargetException;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.alibaba.fastjson.TypeReference;
import com.eos.system.annotation.Bizlet;
import com.pfpj.foundation.database.DatabaseExt;
import com.pfpj.foundation.pfpjcommon.BusinessDictUtil;
import com.psbc.dgtd.img.Base64FileUtil;
import com.psbc.dgtd.util.BusLogUtil;
import com.psbc.dgtd.util.MethUtil;
import com.psbc.pfpj.Util.XmlFileUtil;
import com.psbc.pfpj.ibmmq.PackageHeaderUtil;
import com.psbc.pfpj.ibmmq.SendMsg;
import com.psbc.pfpj.pojo.ALDS001;
import com.psbc.pfpj.pojo.ALDS004;
import com.psbc.pfpj.pojo.ALDS010;
import com.psbc.pfpj.pojo.ALDS011;
import com.psbc.pfpj.pojo.ALDSRoot;
import com.psbc.pfpj.pojo.MsgHeader;
import com.psbc.pfpj.pojo.MsgInShareInfo;
import com.psbc.pfpj.pojo.MsgReturnBody;
import com.psbc.pfpj.pojo.y_interface.Y;
import com.psbc.pfpj.pojo.y_interface.Y030;
import com.psbc.pfpj.pojo.y_interface.YRoot;
import com.psbc.pfpj.pojo.y_interface.YSendFile;
import com.psbs.dgtd.redisUtil.DelFDtatToRedis;
import com.psbs.dgtd.redisUtil.DgRedisKeyArgument;
import com.psbs.dgtd.redisUtil.GetDataToRedis;
import com.psbs.dgtd.redisUtil.PushDataToRedis;
//开户业务
public class BusinessUtil {
	private PackageHeaderUtil pack = new PackageHeaderUtil();
	private SendMsg msg = new SendMsg();
	
	@Bizlet()
	//流水表
	public HashMap<String,Object> getPwKey(HashMap<String,Object> map){
		if(map.get("pw_id")==null || "".equals(map.get("pw_id"))){
	        SimpleDateFormat sf = new SimpleDateFormat("yyyyMMddHHmmss");
	        map.put("createDate",sf.format(new Date()));
	        //获取流水表主键
	  		Object[] objects = DatabaseExt.queryByNamedSql("default","com.psbc.dgtd.business.business.select_pw_key" , null);
	  		String key = objects[0].toString();
	  		map.put("pw_id", key);
			//生成流水表
	  		String bus_type = map.get("bus_type").toString();
	  		if("0".equals(bus_type)){
	  			DatabaseExt.executeNamedSql("default","com.psbc.dgtd.business.business.add_pw" , map);
	  		}else{
	  			DatabaseExt.executeNamedSql("default","com.psbc.dgtd.business.business.add_pw2" , map);
	  		}
		}
		DatabaseExt.executeNamedSql("default","com.psbc.dgtd.business.business.update_pw_bus" , map);
		return map;
	}
	
	@Bizlet()
	//调用接口查询企业信息并保存回显
	public Map<String, Object> queryEnterprise(String unisc_id,String type){
		Map<String,Object> retMap = new HashMap<String, Object>();
		if("0".equals(type)){
			MsgHeader header = pack.packageHeader("ALDS001", "01", null);
			ALDSRoot root = new ALDSRoot();
			ALDS001 a001 = new ALDS001();
			a001.setUnisc_id(unisc_id);
			root.setAlds(a001);
			root.setMsgHeader(header);
			Map<String, Object> map = msg.send(root);
			MsgReturnBody returnBody = ((ArrayList<MsgReturnBody>)map.get("res")).get(0);
			retMap.put("result", returnBody.getQuery_result());//查询结果
			if("00".equals(returnBody.getQuery_result())){
				retMap.put("code", "1");
				retMap.put("enterpriseCode", returnBody.getUnisc_id());//统一社会信用代码
				retMap.put("enterpriseName", returnBody.getEtps_name());//企业名称
				retMap.put("enterpriseAddress", returnBody.getAddress());//住所
				retMap.put("enterpriseTypeName", returnBody.getEtps_type_name());//企业类型
				String a = returnBody.getCptl_total();
				Double d= Double.parseDouble(a);
				DecimalFormat df = new DecimalFormat("0.00");
				retMap.put("cptlTotal", df.format(d));//注册资本
				retMap.put("crncyName", returnBody.getCrncy_name());//注册资本币种
				retMap.put("leaderName", returnBody.getLeader_name());//法定代表人，负责人
				retMap.put("enterpriseTradeScope", returnBody.getTrade_scope());//经营范围
				retMap.put("establishDate", (returnBody.getEstablish_date()));//成立日期
				retMap.put("tradeStartDate", (returnBody.getTrade_start_date()));//营业期限自
				String endDate = "";
				if(returnBody.getTrade_end_date()==null||"".equals(returnBody.getTrade_end_date())){
					endDate = "0000-00-00";
				}else if("不约定期限".equals(returnBody.getTrade_end_date())){
					endDate = "9999-12-31";
				}else{
					endDate = MethUtil.getFormatDate2(returnBody.getTrade_end_date());
				}
				retMap.put("tradeEndDate", endDate);//营业期限至
				retMap.put("regOrgan", returnBody.getReg_organ());//工商登记机关
				retMap.put("applyPerson", returnBody.getApply_person());//申请人
				retMap.put("applyPersonMobile", returnBody.getApply_person_mobile());//申请人手机
				retMap.put("enterprisePostcode", returnBody.getPostcode());//住所邮编
				retMap.put("industryName", returnBody.getIndustry_name());//国民经济行业类型
				retMap.put("industryId", returnBody.getIndustry_id());//国民经济行业代码
				retMap.put("issblicDate", (returnBody.getIssblic_date()));//核准日期
				retMap.put("opsstate", returnBody.getOpsstate());//企业状态
				retMap.put("revokeDate", (returnBody.getRevokeDate()));//吊销日期
				retMap.put("has_ent", "1");
				//查询数据库是否存在该企业
				Object[] objects = DatabaseExt.queryByNamedSql("default","com.psbc.dgtd.business.business.select_enterprise_by_code" , unisc_id);
				if(objects.length>0){//存在企业
					//修改企业
					DatabaseExt.executeNamedSql("default","com.psbc.dgtd.business.business.update_enterprise" , retMap);
				}else{
					//新增企业
					DatabaseExt.executeNamedSql("default","com.psbc.dgtd.business.business.add_enterprise" , retMap);
				}
			}else{
				retMap.put("code", "500");
			}
		}else{
			//查询本地数据库
			Object[] objects = DatabaseExt.queryByNamedSql("default","com.psbc.dgtd.business.business.query_enterprise_by_code" , unisc_id);
			if(objects.length>0){
				retMap = (HashMap<String, Object>) objects[0];
				retMap.put("code", "1");
				retMap.put("has_ent", "1");//存在企业
			}else{
				retMap.put("code", "1");
				retMap.put("has_ent", "0");//不存在企业
			}
		}
		
		//添加受益人信息
		Object[] bens = DatabaseExt.queryByNamedSql("default","com.psbc.dgtd.business.business.query_local_ben" , unisc_id);
		if(bens.length>0){
			retMap.put("has_ben","1");
			retMap.put("ben_infos",bens);
		}else{
			retMap.put("has_ben","0");
		}
		return retMap;
	}
	
	@Bizlet()
	//关联企业查询-接口
	public Object[] queryRelEnterprise(String unisc_id,String etps_name,String cetf_id,String leader_name,String lic_cetf_id,String investor_name){
		int index = 0;
		String msgs1="ALDS010";
		String msgs2="ALDS011";
		Map<String,Object> maps;
		Object[] objects={};
		Set<Map<String, Object>> set = new HashSet<>();
		do {
			ALDSRoot root = new ALDSRoot();
			if(index==0){
				ALDS010 alds010 = new ALDS010();
				alds010.setUnisc_id(unisc_id);
				alds010.setEtps_name(etps_name);
				alds010.setCetf_id(cetf_id);
				alds010.setLeader_name(leader_name);
				MsgHeader header = pack.packageHeader(msgs1, "01", null);
				root.setAlds(alds010);
				root.setMsgHeader(header);
			}else if(index==1){
				ALDS011 alds011 = new ALDS011();
				alds011.setUnisc_id(unisc_id);
				alds011.setEtps_name(etps_name);
				alds011.setLic_cetf_id(lic_cetf_id);
				alds011.setInvestor_name(investor_name);
				MsgHeader header = pack.packageHeader(msgs2, "01", null);
				root.setAlds(alds011);
				root.setMsgHeader(header);
			}
			Map<String, Object> map = msg.send(root);
			MsgReturnBody returnBody = (MsgReturnBody) map.get("res");
			Map<String,Object> retMap = new HashMap<String, Object>();
			retMap.put("result", returnBody.getQuery_result());//查询结果
			if("00".equals(returnBody.getQuery_result())){
				int size = returnBody.getList().size();
				for (int i = 0; i <size ; i++) {
					maps=new HashMap<String, Object>();
					maps.put("enterpriseCode",returnBody.getList().get(i).getUnisc_id());//统一社会信用代码
					maps.put("enterpriseName",returnBody.getList().get(i).getEtps_name());//企业名称
					maps.put("leaderName",returnBody.getList().get(i).getLeader_name());//法人名称
					maps.put("orgcode",returnBody.getList().get(i).getUnisc_id().substring(8, 17));//组织机构代码
					maps.put("estdate",returnBody.getList().get(i).getEstablish_date());//成立日期
					set.add(maps);
				}
			}
			index++;
		} while (cetf_id!=null&&lic_cetf_id!=null&&!lic_cetf_id.equals(cetf_id)&&index<2);
		objects=set.toArray(new Object[set.size()]);
		return objects;
	}
	
	@Bizlet()
	//关联企业查询-本地
	public Object[] queryRelEnterpriseLocal(String rel_id){
		String rel_ids = "";
		if(rel_id.length()<=18){
			rel_ids = "'"+rel_id+"'";
		}else{
			String[] ids = rel_id.split(",");
			for (String id : ids) {
				if(rel_ids.length()==0){
					rel_ids = "'" + id + "'";
				}else{
					rel_ids = rel_ids + ",'" + id + "'";
				}
			}
		}
		//查询本地企业信息
		Object[] objects = DatabaseExt.queryByNamedSql("default","com.psbc.dgtd.business.business.select_rel_local" , rel_ids);
		return objects;
	}
	
	@Bizlet()
	//保存人员
	public void addPase(HashMap<String,Object> enterprise,HashMap<String,Object>[] arr){
		String enterpriseCode = enterprise.get("enterprise_code").toString();
		String pw_id = enterprise.get("pw_id").toString();
		DatabaseExt.executeNamedSql("default","com.psbc.dgtd.business.business.delete_pase" , enterprise);
		//新增人员
		for (HashMap<String,Object> pashMap : arr) {
			pashMap.put("enterpriseCode", enterpriseCode);
			pashMap.put("pw_id", pw_id);
			DatabaseExt.executeNamedSql("default","com.psbc.dgtd.business.business.add_pase" , pashMap);
			if("0".equals(pashMap.get("pase_type"))){
				DatabaseExt.executeNamedSql("default","com.psbc.dgtd.business.business.add_leader_info" , pashMap);
			}
		}
	}
	
	@Bizlet()
	//开户点击保存时调用
	public void saveEnterprise(HashMap<String,Object> map){
		//查询数据库是否存在该企业
		Object[] objects = DatabaseExt.queryByNamedSql("default","com.psbc.dgtd.business.business.select_enterprise_by_code" , map.get("enterprise_code"));
		if(objects.length>0){//存在企业
			//修改企业
			DatabaseExt.executeNamedSql("default","com.psbc.dgtd.business.business.save_enterprise2" , map);
		}else{
			//新增企业
			DatabaseExt.executeNamedSql("default","com.psbc.dgtd.business.business.save_enterprise1" , map);
		}
	}
	
	@Bizlet()
	//开立单位银行账户结算申请书
	public HashMap<String,Object> saveRmbOpenAccount(HashMap<String,Object> map,HashMap<String,Object> enterprise){
		//关联企业
		if(map.get("is_it_rel")!=null && "0".equals(map.get("is_it_rel"))){
			if(map.get("rel_ent_all")!=null){
				Object[] objs = (Object[]) map.get("rel_ent_all");
				String rel_id = "";
				for (Object obj : objs) {
					HashMap<String,Object> map2 = (HashMap<String,Object>)obj;
					//查询数据库是否存在该关联企业
					Object[] objects = DatabaseExt.queryByNamedSql("default","com.psbc.dgtd.business.business.select_rel_enterprise_by_code" , map2);
					if(objects.length>0){//存在企业
						//修改企业
						DatabaseExt.executeNamedSql("default","com.psbc.dgtd.business.business.update_rel_enterprise" , map2);
					}else{
						//新增企业
						DatabaseExt.executeNamedSql("default","com.psbc.dgtd.business.business.add_rel_enterprise" , map2);
					}
					if(rel_id.length()==0){
						rel_id = rel_id + map2.get("enterpriseCode");
					}else{
						rel_id = rel_id + "," + map2.get("enterpriseCode");
					}
				}
				map.put("rel_id", rel_id);
			}
		}
		
		if(map.get("rmb_open_account_id")==null || "".equals(map.get("rmb_open_account_id"))){
			//获取开户表主键
			Object[] objects = DatabaseExt.queryByNamedSql("default","com.psbc.dgtd.business.business.select_rmb_open_account_key" , null);
			String key = objects[0].toString();
			map.put("rmb_open_account_id",key);
			//生成开户表
			DatabaseExt.executeNamedSql("default","com.psbc.dgtd.business.business.add_rmb_open_account" , map);
		}
		map.put("pw_id",enterprise.get("pw_id"));
		map.put("enterprise_name",enterprise.get("enterprise_name"));
		map.put("enterprise_address",enterprise.get("enterprise_address"));
		map.put("cptl_total",enterprise.get("cptl_total"));
		map.put("enterprise_trade_scope",enterprise.get("enterprise_trade_scope"));
		//修改开立单位银行账户结算申请书
		DatabaseExt.executeNamedSql("default","com.psbc.dgtd.business.business.save_rmb_open_account" , map);
		return map;
	}
	
	@Bizlet()
	//单位账户业务申请书
	public HashMap<String,Object> saveUserCollectRmb(HashMap<String,Object> map,HashMap<String,Object> enterprise){
		if(map.get("user_collect_rmb_id")==null || "".equals(map.get("user_collect_rmb_id"))){
			//获取单位账户业务申请书表主键
			Object[] objects = DatabaseExt.queryByNamedSql("default","com.psbc.dgtd.business.business.select_user_collect_rmb_key" , null);
			String key = objects[0].toString();
			map.put("user_collect_rmb_id",key);
			//生成单位账户业务申请书表
			DatabaseExt.executeNamedSql("default","com.psbc.dgtd.business.business.add_user_collect_rmb" , map);
		}
		map.put("pw_id",enterprise.get("pw_id"));
		map.put("ent_code", enterprise.get("enterprise_code"));
		//修改单位账户业务申请书
		DatabaseExt.executeNamedSql("default","com.psbc.dgtd.business.business.save_user_collect_rmb" , map);
		return map;
	}
	
	@Bizlet()
	//客户受益所有人信息表
	public HashMap<String,Object> saveProfitPersonInfo(HashMap<String,Object> map,HashMap<String,Object> enterprise){
		if(map.get("ben_id")==null || "".equals(map.get("ben_id"))){
			//获取客户受益信息记录表主键
			Object[] objects = DatabaseExt.queryByNamedSql("default","com.psbc.dgtd.business.business.select_beneficial_key" , null);
			String key = objects[0].toString();
			map.put("ben_id",key);
			//生成客户受益信息记录表
			DatabaseExt.executeNamedSql("default","com.psbc.dgtd.business.business.add_beneficial" , map);
		}else{
			//删除人
			if(map.get("ben_infos")!=null && map.get("ben_infos").toString().length()>0){
				DatabaseExt.executeNamedSql("default","com.psbc.dgtd.business.business.del_beneficial_info" , map);
			}
		}
		map.put("pw_id",enterprise.get("pw_id"));
		String ben_infos = "";
		for(int i=1;i<10;i++){
			if(map.get("ppi_syr_name"+i)==null || "".equals(map.get("ppi_syr_name"+i))){
				continue;
			}else{
				Map<String,Object> person = new HashMap<String,Object>();
				person.put("sort_no", i);
				person.put("ppi_syr_addr", map.get("ppi_syr_addr"+i));
				person.put("ppi_syr_cert_date", map.get("ppi_syr_cert_date"+i));
				person.put("ppi_syr_cert_no", map.get("ppi_syr_cert_no"+i));
				person.put("ppi_syr_cert_type", map.get("ppi_syr_cert_type"+i));
				person.put("ppi_syr_name", map.get("ppi_syr_name"+i));
				person.put("ppi_syr_nature", map.get("ppi_syr_nature"+i));
				person.put("ppi_syr_phone", map.get("ppi_syr_phone"+i));
				//查询受益人ID
				Object[] objects1 = DatabaseExt.queryByNamedSql("default","com.psbc.dgtd.business.business.select_beneficial_info_key" , null);
				String info_id = objects1[0].toString();
				person.put("beni_id", info_id);
				//新增受益人
				DatabaseExt.executeNamedSql("default","com.psbc.dgtd.business.business.add_beneficial_info" , person);
				if(ben_infos.length()==0){
					ben_infos = ben_infos + info_id;
				}else{
					ben_infos = ben_infos + "," + info_id;
				}
			}
		}
		map.put("ben_infos", ben_infos);
		map.put("ent_code", enterprise.get("enterprise_code"));
		map.put("date", MethUtil.getCurDate());
		//修改客户受益所有人信息表
		DatabaseExt.executeNamedSql("default","com.psbc.dgtd.business.business.save_beneficial" , map);
		return map;
	}
	
	@Bizlet()
	//自然人信息表
	public HashMap<String,Object> saveArtificialPersonInfo(HashMap<String,Object> map,HashMap<String,Object> enterprise){
		if(map.get("natural_id")==null || "".equals(map.get("natural_id"))){
			//获取自然人信息记录表主键
			Object[] objects = DatabaseExt.queryByNamedSql("default","com.psbc.dgtd.business.business.select_beneficial_key" , null);
			String key = objects[0].toString();
			map.put("natural_id",key);
			//生成自然人信息记录表
			DatabaseExt.executeNamedSql("default","com.psbc.dgtd.business.business.add_natural" , map);
		}else{
			//删除人
			if(map.get("natural_infos")!=null && map.get("natural_infos").toString().length()>0){
				DatabaseExt.executeNamedSql("default","com.psbc.dgtd.business.business.del_beneficial_info1" , map);
			}
		}
		map.put("pw_id",enterprise.get("pw_id"));
		String natural_infos = "";
		for(int i=1;i<10;i++){
			if(map.get("api_syr_name"+i)==null || "".equals(map.get("api_syr_name"+i))){
				continue;
			}else{
				Map<String,Object> person = new HashMap<String,Object>();
				person.put("sort_no", i);
				person.put("ppi_syr_addr", map.get("api_syr_addr"+i));
				person.put("ppi_syr_cert_date", map.get("api_syr_cert_date"+i));
				person.put("ppi_syr_cert_no", map.get("api_syr_cert_no"+i));
				person.put("ppi_syr_cert_type", map.get("api_syr_cert_type"+i));
				person.put("ppi_syr_name", map.get("api_syr_name"+i));
				person.put("ppi_syr_nature", map.get("api_syr_nature"+i));
				person.put("ppi_syr_phone", map.get("api_syr_phone"+i));
				//查询自然人ID
				Object[] objects1 = DatabaseExt.queryByNamedSql("default","com.psbc.dgtd.business.business.select_beneficial_info_key" , null);
				String info_id = objects1[0].toString();
				person.put("beni_id", info_id);
				//新增自然人
				DatabaseExt.executeNamedSql("default","com.psbc.dgtd.business.business.add_beneficial_info" , person);
				if(natural_infos.length()==0){
					natural_infos = natural_infos + info_id;
				}else{
					natural_infos = natural_infos + "," + info_id;
				}
			}
		}
		map.put("natural_infos", natural_infos);
		map.put("ent_code", enterprise.get("enterprise_code"));
		map.put("date", MethUtil.getCurDate());
		//修改自然人信息表
		DatabaseExt.executeNamedSql("default","com.psbc.dgtd.business.business.save_natural" , map);
		return map;
	}
	
	@Bizlet()
	//去除重复人员
	public Map<String,Object>[] deleteCompletePase(HashMap<String,Object>[] pases){
		List<String> list = new ArrayList<String>();
		List<HashMap<String,Object>> list1 = new ArrayList<HashMap<String,Object>>();
		for (HashMap<String,Object> pase : pases) {
			if(pase.get("PASE_NAME")==null){
				continue;             
			}
			String name = pase.get("PASE_NAME").toString();
			if(!list.contains(name)){
				list1.add(pase);
				list.add(name);
			}
		}
		Map<String,Object>[] map = new HashMap[list1.size()];
		for(int i =0;i<list1.size();i++){
			map[i] = list1.get(i);
		}
		return map;
	}
	
	/**
	 *  查询企业股东信息记录受益人（出资占比达到25%列入受益人队列）
	 *  
	 * @param unisc_id
	 * @param num     //初始化出资占比     
	 * @return
	 */   
	@Bizlet()
	public HashMap<String,Object> queryBeneFiciary(String unisc_id,String num){
		HashMap<String,Object> retMap = new HashMap<String,Object>();
		BigDecimal rateflag = new BigDecimal(num);    //比例初始值
		BigDecimal ratFlag = new BigDecimal(num);    //总出资比例			     
		BigDecimal rateflagRight = new BigDecimal("0.25"); // 占比25%的标志位
		String ENT_CPTL_TOTAL = "";  //当前企业的注册资金
		String ENT_CRNCY_NAME = "";   //当前企业注册资金的币种
		BigDecimal eNT_CPTL_TOTAL_bDecimal;  //当前企业的注册资金通过外汇汇率换算成人民币后的金额
		//查询当前机构的注册资金和币种
		String sqlPath = "com.psbc.dgtd.business.business.select_ent_register_amt";
		Object[] resultObjects = DatabaseExt.queryByNamedSql("default",sqlPath,unisc_id);
		Map<String,Object> resultMap = (Map<String,Object>)resultObjects[0];
		if(resultMap.get("ENT_CPTL_TOTAL")==null||"".equals(resultMap.get("ENT_CPTL_TOTAL"))||resultMap.get("ENT_CRNCY_NAME")==null||"".equals(resultMap.get("ENT_CRNCY_NAME"))){
			retMap.put("code", "500");
			retMap.put("msg", "注册资金或币种为空,请填写后保存再查询!");
			return retMap;
		}
		ENT_CPTL_TOTAL = resultMap.get("ENT_CPTL_TOTAL").toString();
		ENT_CRNCY_NAME = resultMap.get("ENT_CRNCY_NAME").toString();
		eNT_CPTL_TOTAL_bDecimal = MethUtil.rateToAmt(ENT_CPTL_TOTAL, ENT_CRNCY_NAME);  //换算后的企业注册资金
		List<Map<String,Object>> list = new ArrayList<Map<String,Object>>();      //用于记录受益人名称
		MsgHeader header = pack.packageHeader("ALDS004", "01", null);
		ALDSRoot root = new ALDSRoot();
		ALDS004 a004 = new ALDS004();
		a004.setUnisc_id(unisc_id);
		root.setAlds(a004);
		root.setMsgHeader(header);
		Map<String,Object> res = msg.send(root);
		MsgReturnBody returnBody = ((ArrayList<MsgReturnBody>)res.get("res")).get(0);
		DecimalFormat df = new DecimalFormat("0.00");
		df.setRoundingMode(RoundingMode.FLOOR);
		if("00".equals(returnBody.getQuery_result())){   //00--查询成功
			List<MsgInShareInfo> msgInShareInfos = returnBody.getShareInfo();
			DelFDtatToRedis.delDataToRedis(DgRedisKeyArgument.DG_BEN_MAP, unisc_id);
			//受益人树状图使用
			List<HashMap<String,Object>> treeList = new ArrayList<HashMap<String,Object>>();
			HashMap<String,Object> rootTreeMap = new HashMap<String,Object>();
			rootTreeMap.put("name", resultMap.get("ENT_NAME"));
			rootTreeMap.put("rate", "100");
			rootTreeMap.put("type", "无");
			rootTreeMap.put("unisc_id", unisc_id);
			treeList.add(rootTreeMap);
			//最终受益人缓存-树状图使用
			HashMap<String,Object> benCache = new HashMap<String,Object>();
			//间接持股计算
			String redisData = GetDataToRedis.getRedisData(DgRedisKeyArgument.DG_BEN_MAP, unisc_id);
    		HashMap<String,Object> ben;
    		if(redisData==null){
    			ben = new HashMap<String, Object>();
    		}else{
    			ben = (HashMap<String, Object>)JSON.parse(redisData);
    		}
			//遍历股东信息
			for(MsgInShareInfo msgInShareInfo:msgInShareInfos){
				//返回经过汇率换算的认缴金额
				if(msgInShareInfo.getInvt_cptl()==null||"".equals(msgInShareInfo.getInvt_cptl())||
						msgInShareInfo.getInvt_cptl_crncy_gb()==null||"".equals(msgInShareInfo.getInvt_cptl_crncy_gb())){
					retMap.put("code", "500");
					retMap.put("msg", "接口查询不到结果");
					return retMap;
				}
				BigDecimal rateDecimal = MethUtil.rateToAmt(msgInShareInfo.getInvt_cptl(),msgInShareInfo.getInvt_cptl_crncy_gb());
				//计算占比
				BigDecimal rate	= rateDecimal.divide(eNT_CPTL_TOTAL_bDecimal,5,BigDecimal.ROUND_FLOOR);   //四舍五入
				rateflag = rateflag.subtract(rate);   //剩余出资占比
			    rate = rate.multiply(ratFlag);    //计算真实的出资占比
				if(rate.compareTo(rateflagRight)!=-1){   //compareTo  返回值为-1为小于 0 等于 1大于
					Map<String,Object> map = new HashMap<String,Object>();
					map.put("name",msgInShareInfo.getInvestor_name());   //受益人的名称 
					map.put("type",msgInShareInfo.getInvestor_type());   //受益人的股东类型
					map.put("rate",rate); //受益人的出资占比
					list.add(map);   //将受益人信息加入到list集合中  
			    }else{
			    	if("自然人股东".equals(msgInShareInfo.getInvestor_type())){
			    		if(ben.get(msgInShareInfo.getInvestor_name())==null){
			    			ben.put(msgInShareInfo.getInvestor_name(), rate.toString());
						}else{
							rate = rate.add(new BigDecimal(ben.get(msgInShareInfo.getInvestor_name()).toString()));
							ben.put(msgInShareInfo.getInvestor_name(), rate.toString());
						}
			    	}else{
			    		Map<String,Object> map = new HashMap<String,Object>();
						map.put("name",msgInShareInfo.getInvestor_name());   //受益人的名称 
						map.put("type",msgInShareInfo.getInvestor_type());   //受益人的股东类型
						map.put("rate",rate); //受益人的出资占比
						list.add(map);   //将受益人信息加入到list集合中  
			    	}
			    }
				HashMap<String,Object> treeMap = new HashMap<String,Object>();
				treeMap.put("name", msgInShareInfo.getInvestor_name());
				treeMap.put("rate", df.format(rate.doubleValue()*100));
				treeMap.put("entCode", unisc_id);
				treeMap.put("type", msgInShareInfo.getInvestor_type());
				treeList.add(treeMap);
				//受益人树状图缓存
				if("自然人股东".equals(msgInShareInfo.getInvestor_type())){
					if(benCache.get(msgInShareInfo.getInvestor_name())==null){
						benCache.put(msgInShareInfo.getInvestor_name(), rate.doubleValue());
					}else{
						rate = rate.add(new BigDecimal(benCache.get(msgInShareInfo.getInvestor_name()).toString()));
						benCache.put(msgInShareInfo.getInvestor_name(), rate.doubleValue());
					}
				}
				
			}
			//最终受益人转换-树状图
			List<HashMap<String,Object>> benList = new ArrayList<HashMap<String,Object>>();
			if(benCache.size()>0){
				Set<String> set = benCache.keySet();
				Iterator<String> it = set.iterator();
				while(it.hasNext()){
					HashMap<String,Object> calMap = new HashMap<String,Object>();
					String key = it.next();
					calMap.put("name", key);
					calMap.put("rate", df.format(Double.valueOf(benCache.get(key).toString())));
					benList.add(calMap);
				}
			}
			//添加redis信息
			PushDataToRedis.pushMapToRedis(DgRedisKeyArgument.DG_BEN_MAP, unisc_id, ben, "1800");
			PushDataToRedis.pushListToRedis(DgRedisKeyArgument.DG_BEN_LIST, unisc_id, benList, "2592000");
			PushDataToRedis.pushMapToRedis(DgRedisKeyArgument.DG_BEN_CACHE, unisc_id, benCache, "2592000");
			PushDataToRedis.pushListToRedis(DgRedisKeyArgument.DG_BEN_TREE_MAP, unisc_id, treeList, "2592000");
			//添加返回信息
			retMap.put("code", "1");
			retMap.put("list", list);
		}else{
			retMap.put("code", "500");
			retMap.put("msg", "接口查询不到结果");
		}
		return retMap;
	}
	
	/**
	 * 对出资占比达到25%以上的股东类型为企业法人的股东，进行查询该企业中的股东受益人（出资占比达到25%列入受益人队列）
	 * 计算规则   该企业下股东的出资占比*该企业总出资占比的积 大于等于25%
	 * @param unisc_id
	 * @param num     //初始化出资占比     
	 * @return
	 */
	@Bizlet()	
	public List<Map<String,Object>> queryBeneFiciaryMore(String unisc_id,String num,String root_id,String ent_name){
	    BigDecimal rateflag = new BigDecimal(num);
	    BigDecimal rateflagRight = new BigDecimal("0.25"); // 占比25%的标志位
	    String ENT_CPTL_TOTAL = "";  //当前企业的注册资金
	    String ENT_CRNCY_NAME = "";   //当前企业注册资金的币种
	    BigDecimal eNT_CPTL_TOTAL_bDecimal;  //当前企业的注册资金通过外汇汇率换算成人民币后的金额
	    List<Map<String,Object>> list = new ArrayList<Map<String,Object>>();      //用于记录受益人名称
	    DecimalFormat df = new DecimalFormat("0.00");
		df.setRoundingMode(RoundingMode.FLOOR);
	    //查询当前机构的注册资金和币种
	    MsgHeader header = pack.packageHeader("ALDS001", "01", null);
		ALDSRoot root = new ALDSRoot();
		ALDS001 a001 = new ALDS001();
		a001.setUnisc_id(unisc_id);
		root.setAlds(a001);
		root.setMsgHeader(header);
		Map<String,Object> res = msg.send(root);
		MsgReturnBody returnBody2 = ((ArrayList<MsgReturnBody>)res.get("res")).get(0);
		ENT_CPTL_TOTAL = returnBody2.getCptl_total();  //注册资金赋值
		ENT_CRNCY_NAME = returnBody2.getCrncy_name();    //注册币种赋值
		if(ENT_CPTL_TOTAL==null||"".equals(ENT_CPTL_TOTAL)||ENT_CRNCY_NAME==null||"".equals(ENT_CRNCY_NAME)){
			Map<String,Object> map = new HashMap<String,Object>();
			map.put("errorCode", "500");
			map.put("info", "该企业注册资金或币种为空,无法计算受益人!");
			list.add(map);
			return list;
		}
		eNT_CPTL_TOTAL_bDecimal = MethUtil.rateToAmt(ENT_CPTL_TOTAL, ENT_CRNCY_NAME);  //换算后的企业注册资金
		MsgHeader header1 = pack.packageHeader("ALDS004", "01", null);
		ALDS004 a004 = new ALDS004();
		a004.setUnisc_id(unisc_id);
		root.setAlds(a004);
		root.setMsgHeader(header1);
		Map<String,Object> res1 = msg.send(root);
		MsgReturnBody returnBody = ((ArrayList<MsgReturnBody>)res1.get("res")).get(0);					
		if("00".equals(returnBody.getQuery_result())){   //00--查询成功
			//TODO
			String treeData = GetDataToRedis.getRedisData(DgRedisKeyArgument.DG_BEN_TREE_MAP, root_id);
			List<JSONObject> bakList = (List<JSONObject>) JSONArray.parse(treeData);
			List<HashMap<String,Object>> treeList = new ArrayList<HashMap<String,Object>>();
			for (JSONObject jsonObject : bakList) {
				if(ent_name.equals(jsonObject.getString("name"))){
					jsonObject.put("unisc_id", unisc_id);
				}
				treeList.add(JSONObject.parseObject(jsonObject.toJSONString(), new TypeReference<HashMap<String, Object>>(){}));
			}
			//最终受益人缓存-树状图使用
			String cacheData = GetDataToRedis.getRedisData(DgRedisKeyArgument.DG_BEN_CACHE, root_id);
    		HashMap<String,Object> benCache = JSONObject.parseObject(((JSONObject)JSON.parse(cacheData)).toJSONString(), new TypeReference<HashMap<String, Object>>(){});
    		//间接持股计算
			String redisData = GetDataToRedis.getRedisData(DgRedisKeyArgument.DG_BEN_MAP, root_id);
    		HashMap<String,Object> ben;
    		if(redisData==null){
    			ben = new HashMap<String, Object>();
    		}else{
    			ben = JSONObject.parseObject(((JSONObject)JSON.parse(redisData)).toJSONString(), new TypeReference<HashMap<String, Object>>(){});;
    		}
			List<MsgInShareInfo> msgInShareInfos = returnBody.getShareInfo();
			for(MsgInShareInfo msgInShareInfo:msgInShareInfos){
				//返回经过汇率换算的认缴金额
				BigDecimal rateDecimal = MethUtil.rateToAmt(msgInShareInfo.getInvt_cptl(),msgInShareInfo.getInvt_cptl_crncy_gb());
				//计算占比
				BigDecimal rate	= rateDecimal.divide(eNT_CPTL_TOTAL_bDecimal,5,BigDecimal.ROUND_FLOOR);   //四舍五入
				rate = rate.multiply(rateflag);    //计算真实的出资占比        该企业下股东的出资占比*该企业总出资占比的积 大于等于25%
				if(rate.compareTo(rateflagRight)!=-1){   //compareTo  返回值为-1为小于 0 等于 1大于
					Map<String,Object> map = new HashMap<String,Object>();
					map.put("name",msgInShareInfo.getInvestor_name());   //受益人的名称 
					map.put("type",msgInShareInfo.getInvestor_type());   //受益人的股东类型
					map.put("rate", rate); //受益人的出资占比
					map.put("ent_code", unisc_id);
					list.add(map);   //将受益人信息加入到list集合中 
			    }else{
			    	if("自然人股东".equals(msgInShareInfo.getInvestor_type())){
			    		if(ben.get(msgInShareInfo.getInvestor_name())==null){
			    			ben.put(msgInShareInfo.getInvestor_name(), rate.toString());
						}else{
							rate = rate.add(new BigDecimal(ben.get(msgInShareInfo.getInvestor_name()).toString()));
							if(rate.compareTo(rateflagRight)!=-1){
								Map<String,Object> map = new HashMap<String,Object>();
								map.put("name",msgInShareInfo.getInvestor_name());   //受益人的名称 
								map.put("type",msgInShareInfo.getInvestor_type());   //受益人的股东类型
								map.put("rate",rate); //受益人的出资占比
								map.put("ent_code", unisc_id);
								list.add(map);   //将受益人信息加入到list集合中  
								ben.remove(msgInShareInfo.getInvestor_name());
							}else{
								ben.put(msgInShareInfo.getInvestor_name(), rate.toString());
							}
						}
			    	}else{
			    		Map<String,Object> map = new HashMap<String,Object>();
						map.put("name",msgInShareInfo.getInvestor_name());   //受益人的名称 
						map.put("type",msgInShareInfo.getInvestor_type());   //受益人的股东类型
						map.put("rate",rate); //受益人的出资占比
						map.put("ent_code", unisc_id);
						list.add(map);   //将受益人信息加入到list集合中  
			    	}
			    }
				HashMap<String,Object> treeMap = new HashMap<String,Object>();
				treeMap.put("name", msgInShareInfo.getInvestor_name());
				treeMap.put("rate", df.format(rate.doubleValue()*100));
				treeMap.put("entCode", unisc_id);
				treeMap.put("type", msgInShareInfo.getInvestor_type());
				treeList.add(treeMap);
				//受益人树状图缓存
				if("自然人股东".equals(msgInShareInfo.getInvestor_type())){
					if(benCache.get(msgInShareInfo.getInvestor_name())==null){
						benCache.put(msgInShareInfo.getInvestor_name(), rate.doubleValue());
					}else{
						rate = rate.add(new BigDecimal(benCache.get(msgInShareInfo.getInvestor_name()).toString()));
						benCache.put(msgInShareInfo.getInvestor_name(), rate.doubleValue());
					}
				}
			}
			//最终受益人转换-树状图
			List<HashMap<String,Object>> benList = new ArrayList<HashMap<String,Object>>();
			if(benCache.size()>0){
				Set<String> set = benCache.keySet();
				Iterator<String> it = set.iterator();
				while(it.hasNext()){
					HashMap<String,Object> calMap = new HashMap<String,Object>();
					String key = it.next();
					calMap.put("name", key);
					calMap.put("rate", df.format(Double.valueOf(benCache.get(key).toString())));
					benList.add(calMap);
				}
			}
			//添加redis信息
			PushDataToRedis.pushMapToRedis(DgRedisKeyArgument.DG_BEN_MAP, root_id, ben, "1800");
			PushDataToRedis.pushListToRedis(DgRedisKeyArgument.DG_BEN_LIST, root_id, benList, "2592000");
			PushDataToRedis.pushMapToRedis(DgRedisKeyArgument.DG_BEN_CACHE, root_id, benCache, "2592000");
			PushDataToRedis.pushListToRedis(DgRedisKeyArgument.DG_BEN_TREE_MAP, root_id, treeList, "2592000");
		}else{
			Map<String,Object> map = new HashMap<String,Object>();
			map.put("errorCode", "500");
			map.put("info", "查询股东接口失败");
			list.add(map);
		}
		return list;
	}
	
	@Bizlet
	//企业类影像上送
	public HashMap<String,Object> sentDataEnt(HashMap<String,Object> obj){
		HashMap<String,Object> retMap = new HashMap<String,Object>();
		String pw_id = obj.get("pw_id").toString();
		Object[] objects = DatabaseExt.queryByNamedSql("default","com.psbc.dgtd.business.business.query_org_info" , pw_id);
		HashMap<String,Object> map = (HashMap<String, Object>) objects[0];
		obj.put("bank_code",map.get("bank_code"));
		obj.put("bank_foc",map.get("bank_foc"));
		
		//组装报文，判断大小
		String filePath = "";
		if(MethUtil.Systems()){
			filePath = BusinessDictUtil.getDictName("ABF_SYS_FILE_PATH","0000");
		}else{
			filePath = BusinessDictUtil.getDictName("ABF_SYS_FILE_PATH","0001");
		}
		String open_date = MethUtil.getCurDate();
		MsgHeader header = new MsgHeader();
		header.setMsgType("Y030");
		header.setOperType(obj.get("operType").toString());
		header.setRsmk("");
		header = pack.packageHeader(header,obj.get("account_no").toString().trim(),obj.get("account_type").toString().trim(),obj.get("oper_type").toString().trim());
		Y030 y030 = new Y030();
		y030.setOper_type(obj.get("oper_type").toString().trim());
		y030.setAccount_type(obj.get("account_type").toString().trim());
		y030.setCompany_name(obj.get("company_name").toString().trim());
		y030.setAccount_no(obj.get("account_no").toString().trim());
		y030.setAccount_name(obj.get("account_name").toString().trim());
		y030.setBase_account(obj.get("base_account")==null?"":obj.get("base_account").toString().trim());
		y030.setTemp_account(obj.get("temp_account")==null?"":obj.get("temp_account").toString().trim());
		y030.setOpen_date(open_date);
		y030.setUnisc_id(obj.get("unisc_id")==null?"":obj.get("unisc_id").toString().trim());
		y030.setCardId(obj.get("cardId").toString().trim());
		y030.setBank_code(obj.get("bank_code").toString().trim());
		y030.setBank_foc(obj.get("bank_foc").toString().trim());
		y030.setAdd_data_info(obj.get("add_data_info")==null?"":obj.get("add_data_info").toString().trim());
		Object[] files = (Object[]) obj.get("file");
		ArrayList<YSendFile> yfiles = new ArrayList<YSendFile>();
		for(int i=0;i<files.length;i++){
			HashMap<String,Object> file = (HashMap<String,Object>) files[i];
			YSendFile yfile = new YSendFile();
			String imgPath = filePath + File.separator + file.get("ACCE_PATH");
			yfile.setFile_content(new Base64FileUtil().encryptToBase64(imgPath));
			yfile.setFile_ext(file.get("ACCE_TYPE").toString().trim());
			yfile.setFile_type(file.get("IMG_TPYE").toString().trim());
			yfiles.add(yfile);
		}
		y030.setFiles(yfiles);
		YRoot yroot = new YRoot();
		yroot.setMsgHeader(header);
		yroot.setY(y030);
		if(XmlFileUtil.isXmlSizeTooLong(yroot)){
			//小于4M,存入redis
			PushDataToRedis.pushMapToRedis(DgRedisKeyArgument.DG_ENT_IMG_MAP+"_"+MethUtil.getCurDate(), pw_id, obj, "172800");
			obj.put("pw_type", "10");
			DatabaseExt.executeNamedSql("default","com.psbc.dgtd.business.riskControl.update_pw_stat" , obj);
			retMap.put("code", "1");
			retMap.put("msg", "上报成功");
		}else{
			//大于4M
			retMap.put("code", "400");
			retMap.put("msg", "报文大小超过4M,请减小图片大小!");
		}
		return retMap;
	}
	
	@Bizlet
	//定时器跑企业影像上送(前一天)
	public void autoSentDataEnt1() throws Exception{
		List<String> list = GetDataToRedis.getListRedisData(DgRedisKeyArgument.DG_ENT_IMG_MAP+"_"+MethUtil.getCurDateQ());
		String filePath = "";
		if(MethUtil.Systems()){
			filePath = BusinessDictUtil.getDictName("ABF_SYS_FILE_PATH","0000");
		}else{
			filePath = BusinessDictUtil.getDictName("ABF_SYS_FILE_PATH","0001");
		}
		String open_date = MethUtil.getCurDate();
		for (String json : list) {
			JSONObject o = JSONObject.parseObject(json);
			//上报
			MsgHeader header = new MsgHeader();
			header.setMsgType("Y030");
			header.setOperType(o.getString("operType"));
			header.setRsmk("");
			header = pack.packageHeader(header,o.getString("account_no").trim(),o.getString("account_type").trim(),o.getString("oper_type").trim());
			Y030 y030 = new Y030();
			y030.setOper_type(o.get("oper_type")==null?"":o.get("oper_type").toString().trim());
			y030.setAccount_type(o.get("account_type")==null?"":o.get("account_type").toString().trim());
			y030.setCompany_name(o.get("company_name")==null?"":o.get("company_name").toString().trim());
			y030.setAccount_no(o.get("account_no")==null?"":o.get("account_no").toString().trim());
			y030.setAccount_name(o.get("account_name")==null?"":o.get("account_name").toString().trim());
			y030.setBase_account(o.get("base_account")==null?"":o.get("base_account").toString().trim());
			y030.setTemp_account(o.get("temp_account")==null?"":o.get("temp_account").toString().trim());
			y030.setOpen_date(open_date);
			y030.setUnisc_id(o.get("unisc_id")==null?"":o.get("unisc_id").toString().trim());
			y030.setCardId(o.get("unisc_id")==null?"":o.get("cardId").toString().trim());
			y030.setBank_code(o.get("unisc_id")==null?"":o.get("bank_code").toString().trim());
			y030.setBank_foc(o.get("unisc_id")==null?"":o.get("bank_foc").toString().trim());
			y030.setAdd_data_info(o.get("add_data_info")==null?"":o.get("add_data_info").toString().trim());
			JSONArray files = JSONArray.parseArray(o.get("file").toString());
			ArrayList<YSendFile> yfiles = new ArrayList<YSendFile>();
			for(int i=0;i<files.size();i++){
				JSONObject file = (JSONObject) files.get(i);
				YSendFile yfile = new YSendFile();
				String imgPath = filePath + File.separator + file.getString("ACCE_PATH");
				yfile.setFile_content(new Base64FileUtil().encryptToBase64(imgPath));
				yfile.setFile_ext(file.getString("ACCE_TYPE"));
				yfile.setFile_type(file.getString("IMG_TPYE"));
				yfiles.add(yfile);
			}
			y030.setFiles(yfiles);
			YRoot yroot = new YRoot();
			yroot.setMsgHeader(header);
			yroot.setY(y030);
			Map<String, Object> res = msg.send(yroot);
			MsgReturnBody returnBody = (MsgReturnBody) res.get("res");
			String bus_type = "";
			if("01".equals(o.get("oper_type"))){
				bus_type = "开户";
			}else if("02".equals(o.get("oper_type"))){
				bus_type = "变更";
			}else if("03".equals(o.get("oper_type"))){
				bus_type = "销户";
			}else if("04".equals(o.get("oper_type"))){
				bus_type = "展期";
			}
			if("00".equals(returnBody.getRet_code())){
				HashMap<String,Object> pw_map = new HashMap<String,Object>();
				pw_map.put("pw_id", o.getString("pw_id"));
				pw_map.put("pw_type", "0");
				DatabaseExt.executeNamedSql("default","com.psbc.dgtd.business.riskControl.update_pw_stat" , pw_map);
				//添加日志
				String content = "执行企业类"+bus_type+"【流水号"+o.getString("pw_id")+"|"+returnBody.getOri_msg_id()+"|Y030】影像报文【成功】";
				BusLogUtil.addBusLog("500", "1", content);
				new BusEndUtil().BusEndData(o.getString("pw_id"));
			}else{
				//添加日志
				String content = "执行企业类"+bus_type+"【流水号"+o.getString("pw_id")+"|"+returnBody.getOri_msg_id()+"|Y030】影像报文【失败】"+returnBody.getRet_message();
				BusLogUtil.addBusLog("500", "1", content);
			}
		}
	}
	
	@Bizlet
	//定时器跑企业影像上送(当天)
	public void autoSentDataEnt() throws Exception{
		List<String> list = GetDataToRedis.getListRedisData(DgRedisKeyArgument.DG_ENT_IMG_MAP+"_"+MethUtil.getCurDate());
		String filePath = "";
		if(MethUtil.Systems()){
			filePath = BusinessDictUtil.getDictName("ABF_SYS_FILE_PATH","0000");
		}else{
			filePath = BusinessDictUtil.getDictName("ABF_SYS_FILE_PATH","0001");
		}
		String open_date = MethUtil.getCurDate();
		for (String json : list) {
			JSONObject o = JSONObject.parseObject(json);
			//上报
			MsgHeader header = new MsgHeader();
			header.setMsgType("Y030");
			header.setOperType(o.getString("operType"));
			header.setRsmk("");
			header = pack.packageHeader(header,o.getString("account_no").trim(),o.getString("account_type").trim(),o.getString("oper_type").trim());
			Y030 y030 = new Y030();
			y030.setOper_type(o.get("oper_type")==null?"":o.get("oper_type").toString().trim());
			y030.setAccount_type(o.get("account_type")==null?"":o.get("account_type").toString().trim());
			y030.setCompany_name(o.get("company_name")==null?"":o.get("company_name").toString().trim());
			y030.setAccount_no(o.get("account_no")==null?"":o.get("account_no").toString().trim());
			y030.setAccount_name(o.get("account_name")==null?"":o.get("account_name").toString().trim());
			y030.setBase_account(o.get("base_account")==null?"":o.get("base_account").toString().trim());
			y030.setTemp_account(o.get("temp_account")==null?"":o.get("temp_account").toString().trim());
			y030.setOpen_date(open_date);
			y030.setUnisc_id(o.get("unisc_id")==null?"":o.get("unisc_id").toString().trim());
			y030.setCardId(o.get("unisc_id")==null?"":o.get("cardId").toString().trim());
			y030.setBank_code(o.get("unisc_id")==null?"":o.get("bank_code").toString().trim());
			y030.setBank_foc(o.get("unisc_id")==null?"":o.get("bank_foc").toString().trim());
			y030.setAdd_data_info(o.get("add_data_info")==null?"":o.get("add_data_info").toString().trim());
			JSONArray files = JSONArray.parseArray(o.get("file").toString());
			ArrayList<YSendFile> yfiles = new ArrayList<YSendFile>();
			for(int i=0;i<files.size();i++){
				JSONObject file = (JSONObject) files.get(i);
				YSendFile yfile = new YSendFile();
				String imgPath = filePath + File.separator + file.getString("ACCE_PATH");
				yfile.setFile_content(new Base64FileUtil().encryptToBase64(imgPath));
				yfile.setFile_ext(file.getString("ACCE_TYPE"));
				yfile.setFile_type(file.getString("IMG_TPYE"));
				yfiles.add(yfile);
			}
			y030.setFiles(yfiles);
			YRoot yroot = new YRoot();
			yroot.setMsgHeader(header);
			yroot.setY(y030);
			Map<String, Object> res = msg.send(yroot);
			MsgReturnBody returnBody = (MsgReturnBody) res.get("res");
			String bus_type = "";
			if("01".equals(o.get("oper_type"))){
				bus_type = "开户";
			}else if("02".equals(o.get("oper_type"))){
				bus_type = "变更";
			}else if("03".equals(o.get("oper_type"))){
				bus_type = "销户";
			}else if("04".equals(o.get("oper_type"))){
				bus_type = "展期";
			}
			if("00".equals(returnBody.getRet_code())){
				HashMap<String,Object> pw_map = new HashMap<String,Object>();
				pw_map.put("pw_id", o.getString("pw_id"));
				pw_map.put("pw_type", "0");
				DatabaseExt.executeNamedSql("default","com.psbc.dgtd.business.riskControl.update_pw_stat" , pw_map);
				//添加日志
				String content = "执行企业类"+bus_type+"【流水号"+o.getString("pw_id")+"|"+returnBody.getOri_msg_id()+"|Y030】影像报文【成功】";
				BusLogUtil.addBusLog("500", "1", content);
				try {
					new BusEndUtil().BusEndData(o.getString("pw_id"));
				} catch (Exception e) {
					// TODO: handle exception
				}
			}else{
				//添加日志
				String content = "执行企业类"+bus_type+"【流水号"+o.getString("pw_id")+"|"+returnBody.getOri_msg_id()+"|Y030】影像报文【失败】"+returnBody.getRet_message();
				BusLogUtil.addBusLog("500", "1", content);
			}
		}
	}
	@Bizlet
	//定时器跑企业影像上送
	public void add_err_log() throws Exception{
		//添加日志
		String content = "定时器执行企业类影像任务失败，执行任务日期是："+MethUtil.getCurDate();
		BusLogUtil.addBusLog("500", "1", content);
	}
	
	@SuppressWarnings("unchecked")
	@Bizlet
	//非企业类影像上送
	public HashMap<String,Object> sentDataFpeople(HashMap<String,Object> obj){
		HashMap<String,Object> retMap = new HashMap<String,Object>();
		try {
			String pw_id = obj.get("pw_id").toString();
			Object[] objects = DatabaseExt.queryByNamedSql("default","com.psbc.dgtd.business.business.query_org_info" , pw_id);
			HashMap<String,Object> map = (HashMap<String, Object>) objects[0];
			String filePath = "";
			if(MethUtil.Systems()){
				filePath = BusinessDictUtil.getDictName("ABF_SYS_FILE_PATH","0000");
			}else{
				filePath = BusinessDictUtil.getDictName("ABF_SYS_FILE_PATH","0001");
			}
			//上报
			String msgType = obj.get("msgType").toString();
			MsgHeader header = new MsgHeader();
			header.setMsgType(msgType);
			header.setOperType(obj.get("operType").toString());
			header.setRsmk("");
			header = pack.packageHeader(header,obj.get("account_no").toString(),obj.get("account_type").toString(),obj.get("oper_type").toString());
			//通过反射创建Y
			Class yClazz = Class.forName("com.psbc.pfpj.pojo.y_interface."+msgType);
			Object y = yClazz.newInstance();
			yClazz.getMethod("setUnisc_id", String.class).invoke(y, obj.get("unisc_id")==null?"":obj.get("unisc_id").toString().trim());
			yClazz.getMethod("setBank_code", String.class).invoke(y, map.get("bank_code")==null?"":map.get("bank_code").toString().trim());
			yClazz.getMethod("setBank_foc", String.class).invoke(y, map.get("bank_foc")==null?"":map.get("bank_foc").toString().trim());
			yClazz.getMethod("setAccount_no", String.class).invoke(y, obj.get("account_no")==null?"":obj.get("account_no").toString().trim());
			yClazz.getMethod("setCompany_name", String.class).invoke(y, obj.get("company_name")==null?"":obj.get("company_name").toString().trim());
			yClazz.getMethod("setAdd_data_info", String.class).invoke(y, obj.get("add_data_info")==null?"":obj.get("add_data_info").toString().trim());
			yClazz.getMethod("setAccount_type", String.class).invoke(y, obj.get("account_type")==null?"":obj.get("account_type").toString().trim());
			yClazz.getMethod("setAccount_name", String.class).invoke(y, obj.get("account_name")==null?"":obj.get("account_name").toString().trim());
			yClazz.getMethod("setOpen_date", String.class).invoke(y, MethUtil.getCurDate());
			yClazz.getMethod("setOper_type", String.class).invoke(y, obj.get("oper_type")==null?"":obj.get("oper_type").toString().trim());
			yClazz.getMethod("setOper_name", String.class).invoke(y, obj.get("empname")==null?"":obj.get("empname").toString().trim());
			if("Y032".equals(msgType)||"Y033".equals(msgType)){
				yClazz.getMethod("setName_type", String.class).invoke(y, obj.get("name_type")==null?"":obj.get("name_type").toString().trim());
			}else if("Y041".equals(msgType)||"Y044".equals(msgType)||"Y046".equals(msgType)){
				yClazz.getMethod("setOrgan_type", String.class).invoke(y, obj.get("name_type")==null?"":obj.get("name_type").toString().trim());
			}else if("Y045".equals(msgType)){
				yClazz.getMethod("setSpecial_account_type", String.class).invoke(y, obj.get("name_type")==null?"":obj.get("name_type").toString().trim());
			}
			Object[] files = (Object[]) obj.get("file");
			ArrayList<YSendFile> yfiles = new ArrayList<YSendFile>();
			for(int i=0;i<files.length;i++){
				HashMap<String,Object> file = (HashMap<String,Object>) files[i];
				YSendFile yfile = new YSendFile();
				String imgPath = filePath + File.separator + file.get("ACCE_PATH");
				yfile.setFile_content(new Base64FileUtil().encryptToBase64(imgPath));
				yfile.setFile_ext(file.get("ACCE_TYPE").toString().trim());
				yfile.setFile_type(file.get("IMG_TPYE").toString().trim());
				yfiles.add(yfile);
			}
			yClazz.getMethod("setFiles", ArrayList.class).invoke(y, yfiles);
			YRoot yroot = new YRoot();
			yroot.setMsgHeader(header);
			yroot.setY((Y)y);
			YRoot yroot1 = new YRoot();
			yroot1.setMsgHeader(header);
			yroot1.setY((Y)y);
			if(XmlFileUtil.isXmlSizeTooLong(yroot1)){
				Map<String, Object> res = msg.send(yroot);
				MsgReturnBody returnBody = (MsgReturnBody) res.get("res");
				String bus_type = "";
				if("01".equals(obj.get("oper_type"))){
					bus_type = "开户";
				}else if("02".equals(obj.get("oper_type"))){
					bus_type = "变更";
				}else if("03".equals(obj.get("oper_type"))){
					bus_type = "销户";
				}else if("04".equals(obj.get("oper_type"))){
					bus_type = "展期";
				}else if("05".equals(obj.get("oper_type"))){
					bus_type = "补发";
				}else if("06".equals(obj.get("oper_type"))){
					bus_type = "换发";
				}
				if("00".equals(returnBody.getRet_code())){
					//修改流水表状态
					HashMap<String,Object> pw_map = new HashMap<String,Object>();
					pw_map.put("pw_id", obj.get("pw_id"));
					pw_map.put("pw_type", "0");
					pw_map.put("zx_empid", obj.get("empid"));
					DatabaseExt.executeNamedSql("default","com.psbc.dgtd.business.riskControl.update_pw_stat" , pw_map);
					//添加日志
					String content = "执行非企业类"+bus_type+"【流水号"+obj.get("pw_id")+"|"+"帐号"+obj.get("account_no")+"|"+returnBody.getOri_msg_id()+"|"+msgType+"】影像报文【成功】";
					BusLogUtil.addBusLog("500", obj.get("empid").toString(), content);
					retMap.put("code", "1");
					retMap.put("msg", "上报成功");
				}else{
					//添加日志
					String content = "执行非企业类"+bus_type+"【流水号"+obj.get("pw_id")+"|"+"帐号"+obj.get("account_no")+"|"+returnBody.getOri_msg_id()+"|"+msgType+"】影像报文【失败】"+returnBody.getRet_message();
					BusLogUtil.addBusLog("500", obj.get("empid").toString(), content);
					retMap.put("code", "3");
					retMap.put("msg", "上报失败");
				}
			}else{
				//大于4M
				retMap.put("code", "400");
				retMap.put("msg", "报文大小超过4M,请减小图片大小!");
			}
		} catch (InstantiationException e) {
			e.printStackTrace();
		} catch (IllegalAccessException e) {
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (IllegalArgumentException e) {
			e.printStackTrace();
		} catch (InvocationTargetException e) {
			e.printStackTrace();
		} catch (NoSuchMethodException e) {
			e.printStackTrace();
		} catch (SecurityException e) {
			e.printStackTrace();
		}
		return retMap;
	}

	@Bizlet
	//异步非企业影像上报审核结果处理
	public HashMap<String,Object> asyncEntFpeople(HashMap<String,Object> obj) throws Exception{
		Object[] objects = DatabaseExt.queryByNamedSql("default","com.psbc.dgtd.business.business.query_pw_id_by_account" , obj);
		HashMap<String,Object> map = (HashMap<String, Object>) objects[0];
		String text = map.get("content").toString();
		String pw_id = text.substring(text.indexOf("流水号")+3, text.indexOf("|"));
		String bus_type = text.substring(text.indexOf("【")-2, text.indexOf("【"));
		obj.put("pw_id", pw_id);
		if("00".equals(obj.get("check_result"))){//审核通过
			//添加日志
			String content = "非企业类"+bus_type+"【流水号"+obj.get("pw_id")+"|"+"帐号"+obj.get("account_no")+"|"+obj.get("msg_id")+"|Y031】审核结果【成功】。";
			content = content + "审核意见:"+ (("").equals(obj.get("remark"))?"无":obj.get("remark")) +"。";
			content = content + "开户许可编号:"+ (("").equals(obj.get("khxkzno"))?"无":obj.get("khxkzno")) +"。";
			content = content + "账户核准号:"+ (("").equals(obj.get("account_check_no"))?"无":obj.get("account_check_no")) +"。";
			content = content + "附加域:"+ (("").equals(obj.get("add_data_info"))?"无":obj.get("add_data_info")) +"。";
			BusLogUtil.addBusLog("503", "1", content);
			new BusEndUtil().BusEndData(obj.get("pw_id").toString());
		}else{//审核不通过
			obj.put("pw_type", "7");
			DatabaseExt.executeNamedSql("default","com.psbc.dgtd.business.riskControl.update_pw_stat",obj);
			//添加日志
			String content = "非企业类"+bus_type+"【流水号"+obj.get("pw_id")+"|"+"帐号"+obj.get("account_no")+"|"+obj.get("msg_id")+"|Y031】审核结果【失败】。";
			content = content + "审核意见:"+ obj.get("remark")==""?"无":obj.get("remark") +"。";
			content = content + "开户许可编号:"+ obj.get("khxkzno")==""?"无":obj.get("khxkzno") +"。";
			content = content + "账户核准号:"+ obj.get("account_check_no")==""?"无":obj.get("account_check_no") +"。";
			content = content + "附加域:"+ obj.get("add_data_info")==""?"无":obj.get("add_data_info") +"。";
			BusLogUtil.addBusLog("503", "1", content);
			obj.put("title", "您有一条非企业影像上送审核未通过,msg_id:"+obj.get("msg_id"));
			obj.put("url", "util/jsp/buslog/logList.jsp?msg_id="+obj.get("msg_id"));
		}
		return obj;
	}
	
	@Bizlet()
	//销户时查询企业
	public Map<String, Object> queryRepealEnterprise(String unisc_id){
		//查询数据库是否存在该企业
		Object[] objects = DatabaseExt.queryByNamedSql("default","com.psbc.dgtd.business.business.query_enterprise_by_code" , unisc_id);
		Map<String, Object> result = null;
		if(objects.length>0){//存在企业
			//修改企业
			result = (Map<String, Object>) objects[0];
			result.put("has_ent", "0");
		}else{
			result = new HashMap<String, Object>();
			result.put("has_ent", "1");
		}
		return result;
	}
	
	@Bizlet()
	//撤销账户银行结算
	public HashMap<String,Object> saveRmbRepealAccount(HashMap<String,Object> map,HashMap<String,Object> enterprise){
		if(map.get("rmb_repeal_id")==null || "".equals(map.get("rmb_repeal_id"))){
			//获取撤销表主键
			Object[] objects = DatabaseExt.queryByNamedSql("default","com.psbc.dgtd.business.business.select_rmb_repeal_account_key" , null);
			String key = objects[0].toString();
			map.put("rmb_repeal_id",key);
			//新增
			DatabaseExt.executeNamedSql("default","com.psbc.dgtd.business.business.add_rmb_repeal_account" , map);
		}
		map.put("pw_id",enterprise.get("pw_id"));
		map.put("ent_code", enterprise.get("enterprise_code"));
		//修改
		DatabaseExt.executeNamedSql("default","com.psbc.dgtd.business.business.update_rmb_repeal_account" , map);
		return map;
	}
	
	@Bizlet()
	//计算受益人
	public HashMap<String,Object> calBen(HashMap<String,Object>[] rows){
		DecimalFormat df = new DecimalFormat("0.00");
		df.setRoundingMode(RoundingMode.FLOOR);
		HashMap<String,Object> retMap = new HashMap<String,Object>();
		HashMap<String,Object> root = null;
		List<HashMap<String,Object>> enterpriseList = new ArrayList<HashMap<String,Object>>();
		List<HashMap<String,Object>> natureList = new ArrayList<HashMap<String,Object>>();
		List<HashMap<String,Object>> treeList = new ArrayList<HashMap<String,Object>>();
		List<HashMap<String,Object>> otherList = new ArrayList<HashMap<String,Object>>();
		HashMap<String,Object> benMap = new HashMap<String,Object>();
		//归纳
		for(HashMap<String, Object> map : rows){
			if("1".equals(map.get("_id"))){
				root = map;
			}else if("企业法人".equals(map.get("type"))){
				enterpriseList.add(map);
			}else if("自然人股东".equals(map.get("type"))){
				natureList.add(map);
			}else{
				otherList.add(map);
			}
		}
		if(root.get("cptl_tocal")==null||"".equals(root.get("cptl_tocal"))||root.get("currency")==null||"".equals(root.get("currency"))){
			retMap.put("code", "500");
			retMap.put("msg", "注册资金或币种为空!");
			return retMap;
		}
		HashMap<String,Object> rootTreeMap = new HashMap<String,Object>();
		rootTreeMap.put("name", root.get("name"));
		rootTreeMap.put("rate", "100");
		rootTreeMap.put("type", "无");
		rootTreeMap.put("unisc_id", root.get("unisc_id"));
		treeList.add(rootTreeMap);
		//递归计算
		String rate = "1";
		cal(root,enterpriseList,natureList,benMap,rate,treeList,otherList);
		//拆分benMap
		List<HashMap<String,Object>> benList = new ArrayList<HashMap<String,Object>>();
		if(benMap.size()>0){
			Set<String> set = benMap.keySet();
			Iterator<String> it = set.iterator();
			while(it.hasNext()){
				HashMap<String,Object> calMap = new HashMap<String,Object>();
				String key = it.next();
				calMap.put("name", key);
				calMap.put("rate", df.format(Double.valueOf(benMap.get(key).toString())*100));
				benList.add(calMap);
			}
		}
		//添加返回信息
		retMap.put("code", "1");
		retMap.put("benMap",benList);
		PushDataToRedis.pushListToRedis(DgRedisKeyArgument.DG_BEN_LIST, root.get("unisc_id").toString(), benList, "2592000");
		PushDataToRedis.pushListToRedis(DgRedisKeyArgument.DG_BEN_TREE_MAP, root.get("unisc_id").toString(), treeList, "2592000");
		return retMap;
	}

	/**
	 * 计算受益人
	 * @param root 根节点
	 * @param enterpriseList 企业法人集合
	 * @param natureList 自然人集合
	 * @param benMap 受益人集合
	 * @param num 出资占比
	 */
	private void cal(HashMap<String, Object> root,
			List<HashMap<String, Object>> enterpriseList,
			List<HashMap<String, Object>> natureList,
			HashMap<String, Object> benMap, String num,
			List<HashMap<String, Object>> treeList,
			List<HashMap<String, Object>> otherList) {
		BigDecimal rateflag = new BigDecimal(num);    //比例初始值为1
		BigDecimal eNT_CPTL_TOTAL_bDecimal;  //当前企业的注册资金通过外汇汇率换算成人民币后的金额
		eNT_CPTL_TOTAL_bDecimal = MethUtil.rateToAmt(root.get("cptl_tocal").toString(), root.get("currency").toString());  //换算后的企业注册资金
		DecimalFormat df = new DecimalFormat("0.00");
		df.setRoundingMode(RoundingMode.FLOOR);
		//受益人计算  树状图
		for(int i=natureList.size()-1;i>=0;i--){
			HashMap<String, Object> natural = natureList.get(i);
			if(root.get("unisc_id").equals(natural.get("ent_code"))){
				//返回经过汇率换算的认缴金额
				BigDecimal rateDecimal = MethUtil.rateToAmt(natural.get("rate").toString(),natural.get("currency").toString());
				//计算占比
				BigDecimal rate	= rateDecimal.divide(eNT_CPTL_TOTAL_bDecimal,5,BigDecimal.ROUND_FLOOR);   //四舍五入
				rate = rate.multiply(rateflag);    //计算真实的出资占比        该企业下股东的出资占比*该企业总出资占比的积 大于等于25%
				HashMap<String,Object> naturalTreeMap = new HashMap<String,Object>();
				naturalTreeMap.put("name", natural.get("name"));
				naturalTreeMap.put("rate", df.format(rate.doubleValue()*100));
				naturalTreeMap.put("entCode", root.get("unisc_id"));
				naturalTreeMap.put("unisc_id", natural.get("unisc_id"));
				naturalTreeMap.put("type", natural.get("type"));
				treeList.add(naturalTreeMap);
				if(benMap.get(natural.get("name").toString())==null){
					benMap.put(natural.get("name").toString(), rate.doubleValue());
				}else{
					rate = rate.add(new BigDecimal(benMap.get(natural.get("name").toString()).toString()));
					benMap.put(natural.get("name").toString(), rate.doubleValue());
				}
				natureList.remove(i);
			}
		}
		//其他计算  单纯树状图
		for(int i=otherList.size()-1;i>=0;i--){
			HashMap<String, Object> other = otherList.get(i);
			if(root.get("unisc_id").equals(other.get("ent_code"))){
				//返回经过汇率换算的认缴金额
				BigDecimal rateDecimal = MethUtil.rateToAmt(other.get("rate").toString(),other.get("currency").toString());
				//计算占比
				BigDecimal rate	= rateDecimal.divide(eNT_CPTL_TOTAL_bDecimal,5,BigDecimal.ROUND_FLOOR);   //四舍五入
				rate = rate.multiply(rateflag);    //计算真实的出资占比        该企业下股东的出资占比*该企业总出资占比的积 大于等于25%
				HashMap<String,Object> otherTreeMap = new HashMap<String,Object>();
				otherTreeMap.put("name", other.get("name"));
				otherTreeMap.put("rate", df.format(rate.doubleValue()*100));
				otherTreeMap.put("entCode", root.get("unisc_id"));
				otherTreeMap.put("unisc_id", other.get("unisc_id"));
				otherTreeMap.put("type", other.get("type"));
				treeList.add(otherTreeMap);
				otherList.remove(i);
			}
		}
		if(enterpriseList.size()==0||natureList.size()==0){
			return;
		}
		for(int i=enterpriseList.size()-1;i>=0;i--){
			HashMap<String, Object> enterprise = enterpriseList.get(i);
			if(root.get("unisc_id").equals(enterprise.get("ent_code"))){
				//返回经过汇率换算的认缴金额
				BigDecimal rateDecimal = MethUtil.rateToAmt(enterprise.get("rate").toString(),enterprise.get("currency").toString());
				//计算占比
				BigDecimal rate	= rateDecimal.divide(eNT_CPTL_TOTAL_bDecimal,5,BigDecimal.ROUND_FLOOR);   //四舍五入
				rate = rate.multiply(rateflag);    //计算真实的出资占比        该企业下股东的出资占比*该企业总出资占比的积 大于等于25%
				enterpriseList.remove(i);
				HashMap<String,Object> enterpriseTreeMap = new HashMap<String,Object>();
				enterpriseTreeMap.put("name", enterprise.get("name"));
				enterpriseTreeMap.put("rate", df.format(rate.doubleValue()*100));
				enterpriseTreeMap.put("entCode", root.get("unisc_id"));
				enterpriseTreeMap.put("unisc_id", enterprise.get("unisc_id"));
				enterpriseTreeMap.put("type", enterprise.get("type"));
				treeList.add(enterpriseTreeMap);
				cal(enterprise,enterpriseList,natureList,benMap,rate.toString(),treeList,otherList);
			}
		}
	}
	
	@Bizlet()
	//树状图
	public HashMap<String,Object> getTree(String unisc_id){
		HashMap<String,Object> retMap = new HashMap<String,Object>();
		HashMap<String,Object> treeMap = new HashMap<String,Object>();
		String redisData = GetDataToRedis.getRedisData(DgRedisKeyArgument.DG_BEN_TREE_MAP, unisc_id);
		if(redisData==null||"".equals(redisData)){
			retMap.put("code", "3");
			retMap.put("msg", "未找到该企业树状图或日期超过30天，请重新计算受益人");
			return retMap;
		}
		List<JSONObject> list = (List<JSONObject>) JSONArray.parse(redisData);
		List<HashMap<String,Object>> treeList = new ArrayList<HashMap<String,Object>>();
		for (JSONObject jsonObject : list) {
			treeList.add(JSONObject.parseObject(jsonObject.toJSONString(), new TypeReference<HashMap<String, Object>>(){}));
		}
		String benListData = GetDataToRedis.getRedisData(DgRedisKeyArgument.DG_BEN_LIST, unisc_id);
		List<HashMap<String,Object>> benList = (List<HashMap<String, Object>>) JSONArray.parse(benListData);
		//初始化
		treeMap = treeList.get(0);
		treeList.remove(0);
		//递归
		if(treeList.size()>0){
			calChild(treeMap,treeList);
		}
		retMap.put("code", "1");
		retMap.put("benTree", treeMap);
		retMap.put("benList", benList);
		return retMap;
	}

	//计算树状图
	private void calChild(HashMap<String, Object> parent,
			List<HashMap<String, Object>> treeList) {
		if(treeList.size()==0){
			return;
		}
		String unisc_id = parent.get("unisc_id").toString();
		List<HashMap<String, Object>> childList = new ArrayList<HashMap<String, Object>>();
		for(int i=treeList.size()-1;i>=0;i--){
			HashMap<String, Object> child = treeList.get(i);
			if(unisc_id.equals(child.get("entCode"))){
				childList.add(child);
				treeList.remove(i);
			}
		}
		parent.put("children", childList);
		for (HashMap<String, Object> nextChild : childList) {
			if("企业法人".equals(nextChild.get("type"))){
				calChild(nextChild, treeList);
			}
		}
	}
	
}
