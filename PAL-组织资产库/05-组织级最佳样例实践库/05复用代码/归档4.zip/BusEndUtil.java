package com.psbc.dgtd.business;

import java.util.HashMap;
import java.util.Map;

import com.eos.system.annotation.Bizlet;
import com.pfpj.foundation.database.DatabaseExt;
import com.psbc.dgtd.modify.ModifyData;
import com.psbs.dgtd.redisUtil.DgRedisKeyArgument;
import com.psbs.dgtd.redisUtil.PushDataToRedis;

@Bizlet("")
public class BusEndUtil {

	public void BusEndData(String pw_id) throws Exception {
		Map<String, Object> m = new HashMap<String, Object>();
		m.put("pw_id", pw_id);
		Object[] objs = DatabaseExt.queryByNamedSql("default", "com.psbc.dgtd.business.business.query_pw", m);
		Map<String, Object> map = (HashMap<String, Object>) objs[0];
		String bus_type = map.get("bus_type").toString();//业务类型
		String ent_code = map.get("ent_code").toString();//统一信用代码
		String ent_type = map.get("ent_type").toString();//企业类型
		String bus_nature = map.get("bus_nature").toString();//企业类型
		String pw_sal_type1 = map.get("pw_sal_type1").toString();//类型1
		if ("0".equals(bus_type)) {//开户
			m.put("pw_type", "0");
			DatabaseExt.executeNamedSql("default", "com.psbc.dgtd.business.riskControl.update_pw_stat", m);
		} else if ("1".equals(bus_type)) {//变更
			String orgcode = map.get("gy_orgcode").toString();//开户机构
			new ModifyData().upMoidfyData(ent_code, orgcode, pw_id);
		} else if ("2".equals(bus_type)) {//销户
			new RepealAcction().upRepealData(pw_id, bus_type, bus_nature, ent_type, pw_sal_type1);
		} else if ("3".equals(bus_type)) {//展期
			new RepealAcction().upExtrollData(pw_id);
		} else if ("4".equals(bus_type) || "5".equals(bus_type)) {//补换发
			new RepealAcction().upExtroarData(pw_id, bus_nature);
		}

	}

	/**
	 * 判断是否要上送人行
	 * @param bus_nature
	 * @param ent_type
	 * @param pw_sal_type1
	 * @return
	 */
	public boolean verity(String bus_type, String bus_nature, String ent_type, String pw_sal_type1) {
		if (("1".equals(bus_nature)) || ("0".equals(ent_type) && "0".equals(bus_type) && "2".equals(bus_nature) && "13".equals(pw_sal_type1))
				|| ("0".equals(ent_type) && "1".equals(bus_type) && "2".equals(bus_nature)) || ("0".equals(ent_type) && "2".equals(bus_type) && "2".equals(bus_nature))
				|| ("0".equals(ent_type) && "0".equals(bus_type) && "3".equals(bus_nature) && "44".equals(pw_sal_type1))
				|| ("0".equals(ent_type) && "2".equals(bus_type) && "3".equals(bus_nature) && "44".equals(pw_sal_type1))
				|| ("1".equals(ent_type) && "0".equals(bus_type) && "3".equals(bus_nature) && "44".equals(pw_sal_type1))
				|| ("1".equals(ent_type) && "1".equals(bus_type) && "3".equals(bus_nature) && "44".equals(pw_sal_type1))
				|| ("1".equals(ent_type) && "2".equals(bus_type) && "3".equals(bus_nature) && "44".equals(pw_sal_type1))
				|| ("1".equals(ent_type) && "3".equals(bus_type) && "3".equals(bus_nature) && "44".equals(pw_sal_type1))
				|| ("1".equals(ent_type) && "4".equals(bus_type) && "3".equals(bus_nature) && "44".equals(pw_sal_type1))
				|| ("1".equals(ent_type) && "5".equals(bus_type) && "3".equals(bus_nature) && "44".equals(pw_sal_type1))) {
			return true;
		} else {
			return false;
		}
	}

	@Bizlet("")
	public void EndRect(String account_no, String oper_type,HashMap<String,Object> map) {
		Map o = new HashMap();
		Map<String, Object> res = null;
		Object[] obj = null;
		o.put("seal_account", account_no);
		if ("02".equals(oper_type)) {//变更
			obj = DatabaseExt.queryByNamedSql("default", "com.psbc.dgtd.modify.modify.queryRecData", o);
			res = (HashMap<String, Object>) obj[0];
			String open_pwid = res.get("PW_ID")==null?null:res.get("PW_ID").toString();//原开户流水id
			String mod_pwid = res.get("RCA_PW_ID")==null?null:res.get("RCA_PW_ID").toString();//变更流水id
			String entcode = res.get("PW_ENT_CODE")==null?null:res.get("PW_ENT_CODE").toString();//统一信用代码
			o.put("rca_pw_id", mod_pwid);
			o.put("pw_id", open_pwid);
			map.put("pw_id", mod_pwid);
			DatabaseExt.executeNamedSql("default", "com.psbc.dgtd.modify.modify.update_open_rca_data", o);
			DatabaseExt.executeNamedSql("default", "com.psbc.dgtd.modify.modify.update_rca_data", o);
			PushDataToRedis.pushMapToRedis(DgRedisKeyArgument.DG_MOD_ORG_MAP + "_" + entcode, open_pwid, "00");
		} else if ("03".equals(oper_type)) {//销户
			obj = DatabaseExt.queryByNamedSql("default", "com.psbc.dgtd.business.repeal_account.queryRecData", o);
			res = (HashMap<String, Object>) obj[0];
			String open_pwid = res.get("PW_ID")==null?null:res.get("PW_ID").toString();//原开户流水id
			String mod_pwid = res.get("REP_PW_ID")==null?null:res.get("REP_PW_ID").toString();//销户流水id
			o.put("rep_pw_id", mod_pwid);
			o.put("pw_id", open_pwid);
			map.put("pw_id", mod_pwid);
			DatabaseExt.executeNamedSql("default", "com.psbc.dgtd.business.repeal_account.update_open_rra_data", o);
			DatabaseExt.executeNamedSql("default", "com.psbc.dgtd.business.repeal_account.update_rra_data", o);
		}
		//新增记录
		DatabaseExt.executeNamedSql("default","com.psbc.dgtd.rectification.rectification.add_rectification" , map);
	}

}
