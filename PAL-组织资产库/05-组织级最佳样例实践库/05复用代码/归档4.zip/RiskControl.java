package com.psbc.dgtd.business;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import com.eos.system.annotation.Bizlet;
import com.pfpj.foundation.database.DatabaseExt;

public class RiskControl {
	@Bizlet
	public HashMap<String,Object> checkRisk(HashMap<String,Object> obj){
		HashMap<String,Object> data = new HashMap<String,Object>();
		//查询白名单
		Object[] whiteList = DatabaseExt.queryByNamedSql("default", "com.psbc.dgtd.business.riskControl.check_white_list_by_code", obj);
		if(whiteList.length>0){
			data.put("code", "1");
			data.put("pass", "0");//存在白名单
			obj.put("pw_type", "1");
			DatabaseExt.executeNamedSql("default", "com.psbc.dgtd.business.riskControl.update_pw_stat", obj);
			return data;
		}
		
		//组合人员数据
		List<HashMap<String,Object>> list = new ArrayList<HashMap<String,Object>>();
		for(int i=1;i<10;i++){
			if(obj.get("ppi_syr_name"+i)!=null && obj.get("ppi_syr_name"+i).toString().length()>0){
				HashMap<String,Object> person = new HashMap<String,Object>();
				person.put("name", obj.get("ppi_syr_name"+i));
				person.put("phone", obj.get("ppi_syr_phone"+i));
				person.put("certNo", obj.get("ppi_syr_cert_no"+i));
				list.add(person);
			}
		}
		HashMap<String,Object> person1 = new HashMap<String,Object>();
		HashMap<String,Object> person2 = new HashMap<String,Object>();
		HashMap<String,Object> person3 = new HashMap<String,Object>();
		HashMap<String,Object> person4 = new HashMap<String,Object>();
		person1.put("name", obj.get("rmb_fr_name"));
		person1.put("phone", obj.get("rmb_fr_phone"));
		person1.put("certNo", obj.get("rmb_fr_cert_no"));
		person2.put("name", obj.get("rmb_cwfzr_name"));
		person2.put("phone", obj.get("rmb_cwfzr_phone"));
		person2.put("certNo", obj.get("rmb_cwfzr_cert_no"));
		person3.put("name", obj.get("rmb_gd_name"));
		person3.put("phone", obj.get("rmb_gd_phone"));
		person3.put("certNo", obj.get("rmb_gd_cert_no"));
		list.add(person1);
		list.add(person2);
		list.add(person3);
		if(obj.get("rmb_dlr_name")!=null||!("").equals(obj.get("rmb_dlr_name"))||
				obj.get("rmb_dlr_phone")!=null||!("").equals(obj.get("rmb_dlr_phone"))||
				obj.get("rmb_dlr_cert_no")!=null||!("").equals(obj.get("rmb_dlr_cert_no"))){
			person4.put("name", obj.get("rmb_dlr_name"));
			person4.put("phone", obj.get("rmb_dlr_phone"));
			person4.put("certNo", obj.get("rmb_dlr_cert_no"));
			list.add(person4);
		}
		String checkPhone = "";
		String checkCertNo = "";
		for (HashMap<String, Object> hashMap : list) {
			if(checkPhone.length()>0){
				checkPhone = checkPhone + ",";
				checkCertNo = "" + checkCertNo + ",";
			}
			checkPhone = checkPhone + hashMap.get("phone");
			checkCertNo = checkCertNo + "'" + hashMap.get("certNo") + "'";
		}
		
		//查询黑名单
		HashMap<String,Object> black = new HashMap<String,Object>();
		black.put("entCode", obj.get("enterprise_code"));
		black.put("checkPhone", checkPhone);
		black.put("checkCertNo", checkCertNo);
		Object[] blackList = DatabaseExt.queryByNamedSql("default", "com.psbc.dgtd.business.riskControl.check_black_list", black);
		if(blackList.length>0){
			data.put("code", "1");
			data.put("pass", "1");//存在黑名单
			obj.put("pw_type", "2");
			DatabaseExt.executeNamedSql("default", "com.psbc.dgtd.business.riskControl.update_pw_stat", obj);
			return data;
		}
		
		//查询黑名单地址
		String checkAddress = "";
		try{
			String address = obj.get("enterprise_address").toString();
			checkAddress = address.substring(address.lastIndexOf("路"));
		} catch(Exception e){
			System.out.println("当前输入地址未检测到路字，无法校验黑名单中的地址！");
			checkAddress = "未检测到路字";
		}
		Object[] blackListOfRoad = DatabaseExt.queryByNamedSql("default", "com.psbc.dgtd.business.riskControl.check_black_list_by_road", checkAddress);
		if(blackListOfRoad.length>0){
			String rtnAddress = ((HashMap<String,Object>)blackListOfRoad[0]).get("address").toString();
			data.put("isBlackRoad", "1");//该路名存在黑名单
			data.put("roadMsg", "在该路名下，"+rtnAddress+"属于黑名单，请留意。");
		}else{
			data.put("isBlackRoad", "0");
		}
		
		//查询灰名单
		Object[] greyList = DatabaseExt.queryByNamedSql("default", "com.psbc.dgtd.business.riskControl.check_grey_list", black);
		if(greyList.length>0){
			String greyMsg = "";
			for (Object greyObj : greyList) {
				greyMsg = greyMsg + ((HashMap<String,Object>)greyObj).get("name")+"在灰名单中<br/>";
			}
			data.put("isGreyList", "1");//存在灰名单
			data.put("greyMsg", greyMsg);
		}else{
			data.put("isGreyList", "0");
		}
		
		//查询重点账户标记
		HashMap<String,Object> keyMap = new HashMap<String,Object>();
		keyMap.put("checkCertNo", checkCertNo);
		keyMap.put("address", obj.get("rmb_address"));
		Object[] keyAccount = DatabaseExt.queryByNamedSql("default", "com.psbc.dgtd.business.riskControl.check_key_account", keyMap);
		if(keyAccount.length>0){
			String keyMsg = "";
			for (Object keyObj : keyAccount) {
				HashMap<String,Object> markMap = (HashMap<String, Object>) keyObj;
				if("3".equals(markMap.get("type"))){
					keyMsg = keyMsg + markMap.get("name") + "在重点账户标记中<br/>";
				}else{
					keyMsg = keyMsg + markMap.get("name") + markMap.get("card") + "在重点账户标记中<br/>";
				}
			}
			data.put("isKeyAccount", "1");//存在重点账户标记
			data.put("keyMsg", keyMsg);//
		}else{
			data.put("isKeyAccount", "0");
		}
		
		//校验手机号
		String phone = "0";
		String phoneMsg = "";
		for (HashMap<String, Object> hashMap : list) {
			Object[] phones = DatabaseExt.queryByNamedSql("default", "com.psbc.dgtd.business.riskControl.check_pase", hashMap);
			if(phones.length>0){
				HashMap<String,Object> phoneMap = (HashMap<String, Object>) phones[0];
				phone = "1";//存在重复手机号
				phoneMsg = phoneMsg + hashMap.get("name")+"的手机号"+hashMap.get("phone")+"与"+phoneMap.get("entName")+"下的"+phoneMap.get("name")+"重复<br/>";
			}
		}
		data.put("phoneMsg", phoneMsg);
		data.put("checkPhone", phone);
		data.put("code","1");
		data.put("pass","2");
		return data;
	}
}
