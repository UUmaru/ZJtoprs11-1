package com.psbc.dgtd.business;

import java.util.HashMap;
import java.util.Map;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.eos.system.annotation.Bizlet;
import com.pfpj.foundation.database.DatabaseExt;

@Bizlet("")
public class RepealAcction {

	@SuppressWarnings("unchecked")
	@Bizlet("")
	public JSONArray getPwInfo(Object[] list) {
		Map<String, Object> o = new HashMap<String, Object>();
		Map<String, Object> o1 = new HashMap<String, Object>();
		JSONArray arr =  new JSONArray();
		if (list.length > 0) {
			for (int i = 0; i < list.length; i++) {
				o = (HashMap<String, Object>) list[i];
				o1.put("pw_id", o.get("PW_ID"));
				Object[] objects = DatabaseExt.queryByNamedSql("default", "com.psbc.dgtd.business.business.query_pw",o1);
				o = (HashMap<String, Object>) objects[0];
				arr.add(o);
			}
		}
		return arr;
	}
	
	@Bizlet("完结销户数据")
	public void upRepealData(String pw_id,String bus_type,String bus_nature,String ent_type,String pw_sal_type1) throws Exception{
		boolean b = new BusEndUtil().verity(bus_type,bus_nature, ent_type, pw_sal_type1);
		Map x = new HashMap();
		x.put("pw_id", pw_id);
		x.put("pw_type", "0");
		if("3".equals(bus_nature)){
			x.put("tempno", "1");
		}else{
			x.put("dep_account", "1");
		}
		DatabaseExt.executeNamedSql("default", "com.psbc.dgtd.business.repeal_account.update_rra_original_star", x);
		DatabaseExt.executeNamedSql("default", "com.psbc.dgtd.business.repeal_account.update_new_pw_state", x);
		if(b){
			DatabaseExt.executeNamedSql("default", "com.psbc.dgtd.business.repeal_account.update_open_data", x);
		}
	}
	
	
	
	@Bizlet("完结展期数据")
	public void upExtrollData(String pw_id) throws Exception{
		Map x = new HashMap();
		x.put("pw_id", pw_id);
		x.put("pw_type", "0");
		DatabaseExt.executeNamedSql("default", "com.psbc.dgtd.business.extend.update_new_star", x);
		DatabaseExt.executeNamedSql("default", "com.psbc.dgtd.business.extend.update_extroll_original_open_data", x);
		DatabaseExt.executeNamedSql("default", "com.psbc.dgtd.business.extend.update_extroll_original_star", x);
	}
	
	@Bizlet("完结补换发数据")
	public void upExtroarData(String pw_id,String bus_nature) throws Exception{
		Map x = new HashMap();
		x.put("pw_id", pw_id);
		x.put("pw_type", "0");
		if("3".equals(bus_nature)){
			x.put("tempno", "1");
		}else{
			x.put("dep_account", "1");
		}
		DatabaseExt.executeNamedSql("default", "com.psbc.dgtd.business.extend.update_new_star", x);
		DatabaseExt.executeNamedSql("default", "com.psbc.dgtd.business.extend.update_extroar_original_open_data", x);
		DatabaseExt.executeNamedSql("default", "com.psbc.dgtd.business.extend.update_extroar_original_star", x);
	}
	
}
